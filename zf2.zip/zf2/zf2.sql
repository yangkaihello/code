
DROP TABLE IF EXISTS `vs_account_recharge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vs_account_recharge` (
  `recharge_id` bigint(20) NOT NULL COMMENT '订单ID',
  `user_account` varchar(45) DEFAULT '' COMMENT '用户账号',
  `payment_account` varchar(200) NOT NULL DEFAULT '' COMMENT '付款方账号',
  `pay_status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '支付状态[0未支付][1已经支付]',
  `total_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总金额',
  `order_no` varchar(255) DEFAULT '' COMMENT '商户订单号',
  `transaction_id` varchar(255) DEFAULT '' COMMENT '流水号',
  `create_time` int(11) DEFAULT '0' COMMENT '下单时间',
  `time_pay` int(11) DEFAULT '0' COMMENT '支付时间',
  `time_notice` int(11) DEFAULT '0' COMMENT '后台通知时间',
  `time_verification` int(11) DEFAULT '0' COMMENT '核销时间',
  `time_delete` int(11) DEFAULT '0' COMMENT '作废时间',
  `channel_id` int(11) DEFAULT '0' COMMENT '充值通道',
  `merchant_id` varchar(255) DEFAULT '' COMMENT '商户号',
  `recharge_status` tinyint(2) DEFAULT '1' COMMENT '充值状态[0作废][1有效][2核销]',
  `client_type` tinyint(2) DEFAULT '1' COMMENT '客户端[1pc][2mobile]',
  `client_ip` varchar(45) DEFAULT '' COMMENT '客户IP地址',
  `recharge_remark` varchar(255) DEFAULT '' COMMENT '备注',
  `op_name` varchar(45) DEFAULT '' COMMENT '操作者',
  `auto_time` int(11) DEFAULT '0' COMMENT '同步时间',
  `auto_try` int(11) DEFAULT '0' COMMENT '尝试次数',
  `auto_dispatch` int(11) NOT NULL DEFAULT '1' COMMENT '分配',
  `channel_name` varchar(45) DEFAULT '',
  PRIMARY KEY (`recharge_id`),
  UNIQUE KEY `order_id` (`recharge_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='用户充值表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vs_authorize_admin`
--

DROP TABLE IF EXISTS `vs_authorize_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vs_authorize_admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(45) DEFAULT '' COMMENT '操作员名称',
  `admin_account` varchar(45) DEFAULT '' COMMENT '帐号',
  `admin_password` varchar(45) DEFAULT NULL,
  `admin_level` tinyint(2) DEFAULT '1' COMMENT '管理员权限[0超级管理员][1普通管理员]',
  `create_time` int(11) DEFAULT '0',
  `admin_avatar` varchar(255) DEFAULT '' COMMENT '用户头像',
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='管理员帐号';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vs_authorize_admin`
--

LOCK TABLES `vs_authorize_admin` WRITE;
/*!40000 ALTER TABLE `vs_authorize_admin` DISABLE KEYS */;
INSERT INTO `vs_authorize_admin` VALUES (51,'admin','admin','ca9e9eaade8f663b2e9a730531bd734a',0,1484726739,'/manage/adminlte-2.3.5/dist/img/user3-128x128.jpg');
/*!40000 ALTER TABLE `vs_authorize_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vs_black`
--

DROP TABLE IF EXISTS `vs_black`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vs_black` (
  `black_id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` char(15) NOT NULL,
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `admin_id` int(11) NOT NULL DEFAULT '0' COMMENT '添加人',
  PRIMARY KEY (`black_id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vs_black`
--

LOCK TABLES `vs_black` WRITE;
/*!40000 ALTER TABLE `vs_black` DISABLE KEYS */;
/*!40000 ALTER TABLE `vs_black` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vs_configure`
--

DROP TABLE IF EXISTS `vs_configure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vs_configure` (
  `configure_id` int(11) NOT NULL AUTO_INCREMENT,
  `configure_key` varchar(45) DEFAULT '' COMMENT '设置名称',
  `configure_value` text COMMENT '设置值',
  `create_time` int(11) DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`configure_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='站点配置项';
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `vs_configure` WRITE;
/*!40000 ALTER TABLE `vs_configure` DISABLE KEYS */;
INSERT INTO `vs_configure` VALUES ('3', 'site_name', '充值系统', '1493526798');
INSERT INTO `vs_configure` VALUES ('4', 'min_amount', '0.01', '1502452094');
INSERT INTO `vs_configure` VALUES ('5', 'max_amount', '10000', '1495257062');
INSERT INTO `vs_configure` VALUES ('6', 'customer_url', '', '1493526812');
INSERT INTO `vs_configure` VALUES ('10', 'auto_dispatch', '1', '1484725961');
INSERT INTO `vs_configure` VALUES ('11', 'open_audio', '1', '1504697811');
/*!40000 ALTER TABLE `vs_configure` ENABLE KEYS */;
UNLOCK TABLES;
--
-- Table structure for table `vs_log`
--

DROP TABLE IF EXISTS `vs_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vs_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `op_name` varchar(45) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `op_event` varchar(255) DEFAULT NULL,
  `op_info` varchar(255) DEFAULT '',
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3729 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='操作日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vs_mall_category`
--

DROP TABLE IF EXISTS `vs_mall_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vs_mall_category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(45) DEFAULT '' COMMENT '分类名称',
  `category_status` tinyint(2) DEFAULT '0' COMMENT '板块状态[1开放][0关闭]',
  `category_description` text COMMENT '分类描述',
  `category_ico` varchar(255) DEFAULT '' COMMENT '分类图标',
  `category_order` int(11) DEFAULT '0' COMMENT '排序',
  `create_time` int(11) DEFAULT '0' COMMENT '创建时间',
  `category_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1:第三方支付，2:二维码支付',
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='通道分类表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vs_mall_category`
--

LOCK TABLES `vs_mall_category` WRITE;
/*!40000 ALTER TABLE `vs_mall_category` DISABLE KEYS */;
INSERT INTO `vs_mall_category` VALUES (27,'wx',1,'微信扫码','',1,1476756562,1),(29,'bank',1,'网银支付','',0,1476756556,1),(30,'alipay',1,'支付宝扫码','',0,1477624870,1),(31,'wx',1,'微信APP','',0,1476332035,1),(32,'alipay',1,'支付宝APP','',0,1477446638,1),(33,'qq',1,'QQ钱包','',0,1477446639,1),(34,'wx',1,'微信扫码','',1,1496675750,2),(36,'alipay',1,'支付宝扫码','',1,1491747304,2),(37,'jd',1,'京东钱包','',1,1491747304,2),(38,'baidu',1,'百度钱包','',1,1491747304,2),(39,'unionpay',1,'银联钱包','',0,1507954155,1);
/*!40000 ALTER TABLE `vs_mall_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vs_mall_channel`
--

DROP TABLE IF EXISTS `vs_mall_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vs_mall_channel` (
  `channel_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT '0' COMMENT '分类名称',
  `channel_name` varchar(45) DEFAULT '' COMMENT '商品名称',
  `channel_order` int(11) DEFAULT '0' COMMENT '商品排序',
  `channel_status` tinyint(2) DEFAULT '0' COMMENT '上架和下架[1上架][0下架]',
  `client_type` tinyint(2) DEFAULT '0' COMMENT '推荐客户端[0全部][1pc][2wap]',
  `merchant_id` varchar(255) DEFAULT '' COMMENT '商户号',
  `merchant_key` text COMMENT '密钥',
  `platform_id` varchar(255) DEFAULT '0' COMMENT '平台ID',
  `create_time` int(11) DEFAULT '0' COMMENT '创建时间 ',
  `channel_profile` varchar(255) DEFAULT '' COMMENT '支付简介',
  `channel_host` varchar(255) DEFAULT '' COMMENT '绑定域名',
  `channel_remark` varchar(45) DEFAULT '' COMMENT '通道描述',
  `public_key` text COMMENT '公钥',
  `private_key` text COMMENT '私钥',
  `category_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1:第三方支付，2:二维码支付',
  `media_id` varchar(500) NOT NULL DEFAULT '' COMMENT '二维码图片',
  PRIMARY KEY (`channel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='支付通道表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vs_media`
--

DROP TABLE IF EXISTS `vs_media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vs_media` (
  `media_id` int(11) NOT NULL AUTO_INCREMENT,
  `media_url` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '图片链接',
  `media_status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '内容是否有效[0无效][1有效]',
  `media_type` tinyint(2) NOT NULL DEFAULT '0' COMMENT '多媒体类型[0图片][1视频][2声音]',
  `create_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`media_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='多媒体表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vs_slide`
--

DROP TABLE IF EXISTS `vs_slide`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vs_slide` (
  `slide_id` int(11) NOT NULL AUTO_INCREMENT,
  `slide_link` varchar(255) DEFAULT '' COMMENT '链接地址',
  `slide_target` enum('_parent','_self','_blank') DEFAULT '_blank',
  `slide_order` int(11) DEFAULT '0' COMMENT '排序',
  `slide_pic` varchar(255) DEFAULT '' COMMENT '友情连接的图标',
  `slide_title` varchar(255) DEFAULT '' COMMENT '标题',
  `slide_remark` varchar(45) DEFAULT '' COMMENT '幻灯片标签',
  `create_time` int(11) DEFAULT '0' COMMENT '创建时间',
  `media_ids` varchar(255) DEFAULT '' COMMENT '幻灯片相册',
  PRIMARY KEY (`slide_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='幻灯片';
/*!40101 SET character_set_client = @saved_cs_client */;
