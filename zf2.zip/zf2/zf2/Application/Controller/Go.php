<?php
namespace Controller;
/**
 * 支付跳转
 * @author EVEN
 *
 */
class Go extends \MyController
{
	
    public function get()
    { 
        $v = new \Even\Validation($_GET);
        log_message('page request='.json_encode($_GET));
        log_message('page request='.http_build_query($_GET));
        // 充值ID
        $recharge_id = \Db\Account\Recharge::gen_recharge_id();
        
        // 充值的账号
        $account = trim(get('username'));
        $account = remove_xss($account);
        // 系统订单号
        $order_no = $account.'_'.$recharge_id;  
        // 充值的金额
        $coin = trim(get('coin'));  
        $coin = remove_xss($coin); 
        // 客户端[1pc][2wap]
        $client_type = trim(get('client_type', 1));
        $client_type = remove_xss($client_type);
        // 商品名称
        $product_name = 'recharge';
        // 商品数量
        $product_num = 1;
        // 客户手机
        $customer_phone = '18909091212';
        // 收货地址
        $receive_address = 'china';
        // 附加信息
        $return_params = $order_no;
        // 通道ID
        $channel_id = get('channel_id');
        $channel_id = remove_xss($channel_id);
        $channel = \Db\Mall\Channel::row(array('channel_id'=>$channel_id, 'channel_status'=>1));
        
        if(empty($account))
        {
            $v->append_error(array('message'=>'params error'));
        }
		
		if(stripos($account, "_") !== false)
        {
            $v->append_error(array('message'=>'params error'));
        }
        
        if(empty($channel))
        {
            $v->append_error(array('message'=>'params error'));
        }
        $min_amount = \Db\Configure::get_kv('min_amount');
        if($coin < $min_amount)
        {
            $v->append_error(array('message'=>'params error'));
        }
        
	   	if($coin > \Db\Configure::get_kv('max_amount'))
	   	{
	   	    $v->append_error(array('message'=>'params error'));
	   	}
		//$coin = number_format($coin-(mt_rand(1,50)/100),2,'.','');
        if ($coin < 0) {
            $coin = 0.01;
        }
	   	
        if ($v->validates())
        {
            // 商户号
            $merchant_id = $channel->merchant_id;
            // 密钥
            $public_key = $channel->public_key;
            // 密钥
            $private_key = $channel->private_key;
            // 密钥
            $merchant_key = $channel->merchant_key;
            // 平台ID
            $platform_id = $channel->platform_id;
            // 创建充值订单
            $recharge = new \Db\Account\Recharge();
            $recharge = $recharge->gen_new_recharge($client_type, $recharge_id, $account, $coin, $merchant_id, $channel->channel_id, $channel->channel_name, $order_no);
            // 调用支付页面    
			log_message('pay trans to : '.SP.'Public/'.$channel->category->category_name.DS.$channel->channel_name.DS.'paySubmit.php');
            require_once('../Public/'.$channel->category->category_name.DS.$channel->channel_name.DS.'paySubmit.php');
        }
        else 
        {
            $v->send();
        }
    }
    
    public function post()
    {

        $v = new \Even\Validation($_POST);
        $client_ip = client_ip();
        if(stristr($client_ip, 'script')) {
            log_message('Wain: atack by '.$client_ip);
            exit(0);
        }
        // 充值ID
        $recharge_id = \Db\Account\Recharge::gen_recharge_id();
        
        // 充值的账号
        $account = trim(post('username'));
        $account = remove_xss($account);
        
        // 付款账号
        $paymentaccount = trim(post('paymentaccount',''));
        $paymentaccount = remove_xss($paymentaccount);
        
        // 系统订单号
        $order_no = $account.'_'.$recharge_id;  
        // 充值的金额
        $coin = trim(post('coin'));  
        $coin = remove_xss($coin); 
        // 客户端[1pc][2wap]
        $client_type = trim(post('client_type', 1));
        $client_type = remove_xss($client_type);
        // 商品名称
        $product_name = 'recharge';
        // 商品数量
        $product_num = 1;
        // 客户手机
        $customer_phone = '18909091212';
        // 收货地址
        $receive_address = 'china';
        // 附加信息
        $return_params = $order_no;
        // 通道ID
        $channel_id = post('channel_id');
        $channel_id = remove_xss($channel_id);
        $channel = \Db\Mall\Channel::row(array('channel_id'=>$channel_id, 'channel_status'=>1));
        
        if($channel->category_type==2 && !$paymentaccount) {
            $v->append_error(array('message'=>'params error'));
        }
        
        if(empty($account))
        {
            $v->append_error(array('message'=>'params error'));
        }
        
		if(stripos($account, "_") !== false)
        {
            $v->append_error(array('message'=>'params error'));
        }
		if(stripos($account, "_") !== false)
        {
            $v->append_error(array('message'=>'params error'));
        }
		
        if(empty($channel))
        {
            $v->append_error(array('message'=>'params error'));
        }
        
        if($coin > \Db\Configure::get_kv('max_amount'))
        {
            $v->append_error(array('message'=>'params error'));
        }
        // 九易支付宝固定金额，特殊处理
        $isrand = true;
        if($channel->channel_name == "jiuyi") {
            $category = \Db\Mall\Category::row(array('category_id'=>$channel->category_id));
            if($category->category_name == 'alipay') {
                $isrand = false;
            }
        }
        // huiyin固定金额，特殊处理
        if($channel->channel_name == "huiyin") {
                $isrand = false;
        }
        // 宝马，特殊处理
        if($channel->channel_name == "baoma") {
                $isrand = false;
                $coin = number_format($coin,0,'.','');
        }
        if($isrand) {
            $coin = number_format($coin-(mt_rand(1,50)/100),2,'.','');
        }
        if ($v->validates())
        {
            // 商户号
            $merchant_id = $channel->merchant_id;
            // 密钥
            $public_key = $channel->public_key;
            // 密钥
            $private_key = $channel->private_key;
            // 密钥
            $merchant_key = $channel->merchant_key;
            // 平台ID
            $platform_id = $channel->platform_id;
            // 创建充值订单
            $recharge = new \Db\Account\Recharge();
            
            $recharge = $recharge->gen_new_recharge($client_type, $recharge_id, $account, $coin, $merchant_id, $channel->channel_id, $channel->channel_name,$paymentaccount);
            // 调用支付页面
            if($channel->category_type==1) {
                require_once SP.'Public/'.$channel->category->category_name.DS.$channel->channel_name.DS.'paySubmit.php';
            } else {
                require_once SP.'Public/qrpay/'.$channel->category->category_name.DS.($client_type==1?'pc':'wap').".php";
            }
        }
        else 
        {
            $v->send();
        }

    }
}