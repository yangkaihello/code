<?php
namespace Controller;

class Main extends \MyController
{
	public $maintain = 0;
	
	public $black = array(
	    'pay.dns556.com.cn' => 'www.dns556.com.cn',
	);
    
    public function get()
    {
        if($this->maintain == 1)
        {
            echo new \Micro\View('Maintain');
            exit();
        }
        
        // 商城跳转
        foreach ($this->black as $key => $val)
        {
            if($key == strtolower($_SERVER['SERVER_NAME']))
            {
                redirect('http://'.$val);
            }
        }
        
		if(is_wap())
		{
		    redirect(site_url('wap'));
		}
		else
		{
		    redirect(site_url('pc'));
		}
    }
}