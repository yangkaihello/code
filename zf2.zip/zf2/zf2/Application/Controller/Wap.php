<?php
namespace Controller;

class Wap extends \MyController
{
	
    public function get()
    {
        $view = new \Micro\View('Wap');
//      $view = new \Micro\View('Wap2');
        $rows1 = \Db\Mall\Channel::fetch(array('channel_status'=>1,'category_type'=>1), 0, 0, array('channel_order'=>'desc'));
        $rows2 = \Db\Mall\Channel::fetch(array('channel_status'=>1,'category_type'=>2), 0, 0, array('channel_order'=>'desc'));
        $filter = array();
        foreach($rows1 as $key => $row)
        {
            if($row->client_type != 0 && $row->client_type != 2)
            {
                unset($rows1[$key]);
            }
            else
            {
                $filter[] = $row;
            }
        }
        $view->rows1 = $filter;
        $filter = array();
        foreach($rows2 as $key => $row)
        {
            if($row->client_type != 0 && $row->client_type != 2)
            {
                unset($rows2[$key]);
            }
            else
            {
                $filter[] = $row;
            }
        }
        $view->rows2 = $filter;
        print $view;
    }
}