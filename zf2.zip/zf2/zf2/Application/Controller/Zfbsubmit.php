<?php
namespace Controller;
/**
 * 
 * @author EVEN
 *
 */
class Zfbsubmit extends \MyController
{
	
    public function get()
    {
        $template = is_wap()?'Qrauto/Alipay/Zfbwapsubmit':'Qrauto/Alipay/Zfbpcsubmit';
        $view = new \Micro\View($template);
        print $view;
        return;
    }
    
    public function post()
    {
        $v = new \Even\Validation($_POST);
        
        $username = post('username','');
        $money = post('money','');
        $order = post('order','');
        
        if(empty($username))
        {
            $v->append_error(array('message'=>'params error'));
        }
        
        if(empty($money))
        {
            $v->append_error(array('message'=>'params error'));
        }
        
        if(empty($order) || strlen($order) != 8)
        {
            $v->append_error(array('message'=>'params error'));
        }
        
	   	$return = array(
	   	    'success'=>0
	   	);
        if ($v->validates())
        {
            $orm = new \Db\Account\Recharge\Qrauto\User();
            $orm->category_name = 'alipay';
            $orm->user_account = $username;
            $orm->total_amount = $money;
            $orm->transaction_id = $order;
            $orm->create_time = time();
            $orm->save();
            $return['success'] = 1;
        }
        $v->append_data($return);
        $v->send();

    }
}