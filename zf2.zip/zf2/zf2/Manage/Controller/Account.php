<?php
namespace Manage\Controller;

class Account extends \Manage\Password
{
    
    public function get()
    {
        $this->title = '个人账户';
        $this->content = new \Micro\View('Manage/Account');
        $this->send();
    }
    
    public function post()
    {
        $password = post('password');   
        $new_password = post('new_password');   
        $repeat_password = post('repeat_password');   
        $v = new \Even\Validation($_POST);
        $v->field('password')->required('原密码不能为空');
        $v->field('new_password')->required('新密码不能为空')->true('重复新密码不正确', $new_password == $repeat_password);
        if ($v->validates())
        {
            $admin_id = session('admin_id');
            $row = \Db\Authorize\Admin::row(array('admin_id'=>$admin_id));
            $gen_password = \Db\Authorize\Admin::gen_password($password);
            if ($gen_password == $row->admin_password)
            {
                $row->admin_password = \Db\Authorize\Admin::gen_password($new_password);
                $row->save();
				//$v->append_error(array('message'=>'密码修改成功，退出当前登录生效'));
            }
            else 
            {
            	$v->append_error(array('message'=>'原始密码不正确'));
            }
        }
        $v->send();
    }
}