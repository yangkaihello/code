<?php
namespace Manage\Controller;

class Admin extends \Manage\Password
{
    
    public function get()
    {
        $this->title = '管理员';
        $this->content = new \Micro\View('Manage/Admin');
        
        $page = get('page', 1);
        $limit = 10;
        $offset = ($page -1)*$limit;
        $key = get('key', '');
        $where = array('admin_level' => 1);
        if(!empty($key))
        {
            $where[1] = "user_mobile like '$key%'";
        }
        $this->content->rows = \Db\Authorize\Admin::fetch($where, $limit, $offset, array('create_time'=>'desc'));
        $this->content->page = new \Manage\Model\Pagination(\Db\Authorize\Admin::count($where), $page, $limit, '/manage/admin', array('key'=>$key));
        $this->content->key = $key;
//         var_dump($this->content->page);exit();
        $this->send();
    }
    
    public function delete()
    {
        $admin_id = delete('admin_id');
        $orm = \Db\Authorize\Admin::row(array('admin_id'=>$admin_id));
        if(!empty($orm) && $orm->admin_level != 0)
        {
            $orm->delete();
        }
    }
}