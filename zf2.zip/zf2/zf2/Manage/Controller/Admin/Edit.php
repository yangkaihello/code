<?php
namespace Manage\Controller\Admin;

class Edit extends \Manage\Password
{
    
    public function get()
    {
        $admin_id = get('admin_id');
        $this->title = '管理员';
        $this->content = new \Micro\View('Manage/Admin/Edit');
        $this->content->row = \Db\Authorize\Admin::row(array('admin_id'=>$admin_id));
        $this->send();
    }
}