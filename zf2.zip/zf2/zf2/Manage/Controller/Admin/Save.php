<?php
namespace Manage\Controller\Admin;

class Save extends \Manage\Password
{
    
    public function get()
    {
        $this->title = '添加管理员';
        $this->content = new \Micro\View('Manage/Admin/Save');
        
        $page = get('page', 1);
        $limit = 10;
        $offset = ($page -1)*$limit;
        $key = get('key', '');
        $where = array();
        if(!empty($key))
        {
            $where[1] = "user_mobile like '$key%'";
        }
        $this->content->rows = \Db\Authorize\Admin::fetch($where, $limit, $offset, array('create_time'=>'desc'));
        $this->content->page = new \Manage\Model\Pagination(\Db\Authorize\Admin::count($where), $page, $limit, '/manage/admin', array('key'=>$key));
        $this->content->key = $key;
//         var_dump($this->content->page);exit();
        $this->send();
    }
    
    public function post()
    {
        $v = new \Even\Validation($_POST);
    
        $v->field('admin_name')->required('必须填写真实姓名');
        $v->field('admin_account')->required('必须填写登陆账号');
        $v->field('admin_password')->required('必须填初始密码');
        if(static::$admin->admin_level !=0)
        {
            $v->append_error(array('message'=>'只有超级管理员才有变更账号权限'));
        }
        if ($v->validates())
        {
            $admin_id = post('admin_id', null);
            $orm = new \Db\Authorize\Admin($admin_id);
            $orm->admin_name = post('admin_name');
            $orm->admin_account = post('admin_account');
            $orm->admin_password = \Db\Authorize\Admin::gen_password(post('admin_password'));
            $orm->admin_level = 1;
            $orm->admin_avatar = '/manage/adminlte-2.3.5/dist/img/user3-128x128.jpg';
            $orm->create_time = time();
            $orm->save();
            $v->append_data(array('url'=>'/manage/admin'));
        }
        $v->send();
    }
}