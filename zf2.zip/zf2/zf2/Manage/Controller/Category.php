<?php
namespace Manage\Controller;

class Category extends \Manage\Password
{
    
    public function get()
    {
        $this->title = '通道分类';
        $this->content = new \Micro\View('Manage/Category');
        
        $page = get('page', 1);
        $limit = 10;
        $offset = ($page -1)*$limit;
        $where = array();
        $this->content->rows1 = \Db\Mall\Category::fetch(array('category_type'=>1), $limit, $offset, array('category_order'=>'desc'));
        $this->content->rows2 = \Db\Mall\Category::fetch(array('category_type'=>2), $limit, $offset, array('category_order'=>'desc'));
        $this->send();
    }
    
    /**
     * 上架下架
     */
    public function post()
    {
        $category_id = post('category_id');
        $category_status = post('category_status', 0);
        $orm = \Db\Mall\Category::row(array('category_id'=>$category_id));
        if(!empty($orm))
        {
            $orm->category_status = $category_status;
            $orm->save();
        }
    }
    
    public function delete()
    {
        $delete = \delete();
        $v = new \Even\Validation($delete);
        
        $v->field('category_id')->required('参数错误');
        
        
        $admin = self::login_admin();
        if($admin->admin_level > 0)
        {
            $v->append_error(array('message'=>'您没有权限修改'));
        }
        
        $count = \Db\Mall\Channel::count(array('category_id'=>$delete['category_id']));
        if($count > 0)
        {
            $v->append_error(array('message'=>'该分类下面有相关支付通道，请先删除支付通道'));
        }
        if ($v->validates())
        {
            $orm = \Db\Mall\Category::row(array('category_id'=>$delete['category_id']));
            if(!empty($orm))
            {
                $orm->delete();
            }
        }
        $v->send();
    }
}