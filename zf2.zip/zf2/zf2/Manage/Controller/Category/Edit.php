<?php
namespace Manage\Controller\Category;

class Edit extends \Manage\Password
{
    
    public function get()
    {
        $category_id = get('category_id');
        $this->title = '通道分类';
        $this->content = new \Micro\View('/Manage/Category/Edit');
        $this->content->row = \Db\Mall\Category::row(array('category_id'=>$category_id));
        $this->send();
    }

}