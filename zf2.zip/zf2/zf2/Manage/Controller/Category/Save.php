<?php
namespace Manage\Controller\Category;

class Save extends \Manage\Password
{
    
    public function get()
    {
        $this->title = '通道分类';
        $category_type = get('category_type',1);
        $this->content = new \Micro\View("/Manage/Category/Save");
        
        
        $this->content->category_type = $category_type;
        $this->send();
    }
    
    public function post()
    {
        $v = new \Even\Validation($_POST);
        
        $v->field('category_name')->required('必须填写分类名称');
//         $v->field('category_status')->required('必须填写链接地址');
        $v->field('category_description')->required('必须填写分类描述');
//         $v->field('category_order')->required('必须上传一张图片');

        if ($v->validates())
        {
            $category_id = post('category_id', null);
            $orm = new \Db\Mall\Category($category_id);
            
            $orm->category_name = post('category_name');
            $orm->category_status = post('category_status', 0);
            $orm->category_description = post('category_description');
            $orm->category_order = post('category_order', 0);
            $orm->create_time = time();
            $orm->category_type = post('category_type', 1);
            $orm->save();
            $v->append_data(array('url'=>'/manage/category'));
        }
        $v->send();
    }
}