<?php
namespace Manage\Controller;

class Channel extends \Manage\Password
{
    public function get()
    {
        
        $category_type = get('category_type',1);
        $this->title = ($category_type==1?'第三方':'二维码').'支付平台';
        $this->content = new \Micro\View("/Manage/Channel{$category_type}");
        
        $get = get();
        $v = new \Even\Validation($get);
        
        $page = get('page', 1);
        $limit = 18;
        $offset = ($page -1)*$limit;
        $where = array();
        $key = get('key', '');
        $where = array(
            'category_type'=>$category_type,
        );
        if(!empty($key))
        {
            $where[] = "channel_name like '%$key%' or merchant_id like '%$key%'";
        }
        $this->content->rows = \Db\Mall\Channel::fetch($where, $limit, $offset, array('channel_status'=>'desc', 'channel_order'=>'desc'));
        $this->content->page = new \Manage\Model\Pagination(\Db\Mall\Channel::count($where), $page, $limit, '/manage/channel', $get);
        $this->content->v = $v;
        $this->send();
    }
    
    /**
     * 上架下架
     */
    public function post()
    {
        $channel_id = post('channel_id');
        $channel_status = post('channel_status', 0);
        $orm = \Db\Mall\Channel::row(array('channel_id'=>$channel_id));
        if(!empty($orm))
        {
            $orm->channel_status = $channel_status;
            $orm->save();
        }
    }
    
    /**
     * 删除
     */
    public function delete()
    {
        $delete = \delete();
        $v = new \Even\Validation($delete);
        
        $admin = self::login_admin();
        if($admin->admin_level > 0)
        {
            $v->append_error(array('message'=>'您没有权限修改'));
        }
        $count = \Db\Account\Recharge::count(array('channel_id'=>$delete['channel_id']));
        if($count > 0)
        {
            $v->append_error(array('message'=>'该商户号有相关充值记录，请先删除充值记录'));
        }
        if ($v->validates())
        {
            $orm = \Db\Mall\Channel::row(array('channel_id'=>$delete['channel_id']));
            if(!empty($orm))
            {
                $orm->delete();
            }
        }
        $v->send();
    }
}