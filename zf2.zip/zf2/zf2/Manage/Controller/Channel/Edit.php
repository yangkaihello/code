<?php
namespace Manage\Controller\Channel;

class Edit extends \Manage\Password
{
    
    public function get()
    {
        $channel_id = get('channel_id');
        $this->title = '修改通道';
        $row = \Db\Mall\Channel::row(array('channel_id'=>$channel_id));
        $this->content = new \Micro\View("/Manage/Channel/Edit{$row->category_type}");
        $this->content->row = $row;
        $this->content->category = \Db\Mall\Category::fetch(array('category_status'=>1), 0, 0, array('category_order'=>'desc'));
        $this->send();
    }
}