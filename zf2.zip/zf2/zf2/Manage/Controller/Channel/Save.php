<?php
namespace Manage\Controller\Channel;

class Save extends \Manage\Password
{
    
    public function get()
    {
        
        $category_type = get('category_type',1);
        $this->title = '添加'.($category_type==1?'第三方':'二维码').'通道';
        $this->content = new \Micro\View("/Manage/Channel/Save{$category_type}");
        $this->content->category = \Db\Mall\Category::fetch(array('category_status'=>1,'category_type'=>$category_type), 0, 0, array('category_order'=>'desc'));
        $this->content->category_type = $category_type;
        $this->send();
    }
    
    public function post()
    {
    	$admin = self::login_admin();
		
        $v = new \Even\Validation($_POST);
        
        $category_type = post('category_type',1);
        if($category_type == 1) {
            $v->field('channel_name')->required('必须填写支付名称');
            $v->field('category_id')->required('必须选择一个分类');
            $v->field('merchant_id')->required('必须填写商户号');
            //$v->field('merchant_key')->required('必须填写商户密钥');
            if($admin->admin_level > 0)
    		{
    			$v->append_error(array('message'=>'您没有权限修改'));
    		}
            if ($v->validates())
            {
                $channel_id = post('channel_id', null);
                $orm = new \Db\Mall\Channel($channel_id);
                
                $orm->channel_name = post('channel_name');
                $orm->category_id = post('category_id');
                $orm->merchant_id = post('merchant_id');
                $orm->merchant_key = post('merchant_key');
                $orm->public_key = post('public_key');
                $orm->private_key = post('private_key');
                $orm->platform_id = post('platform_id', '');
                $orm->channel_order = post('channel_order');
                $orm->channel_status = post('channel_status', 0);
                $orm->client_type = post('client_type', 0);
                $orm->channel_remark = post('channel_remark', '');
                $orm->channel_host = post('channel_host', '');
                $orm->create_time = time();
                $orm->category_type = $category_type;
                $orm->save();
                $v->append_data(array('url'=>"/manage/channel?category_type={$category_type}"));
            }
        } else {
            $v->field('channel_name')->required('必须填写支付名称');
            $v->field('category_id')->required('必须选择一个分类');
            //$v->field('merchant_id')->required('必须填写商户号');
            //$v->field('merchant_key')->required('必须填写商户密钥');
            if($admin->admin_level > 0)
    		{
    			$v->append_error(array('message'=>'您没有权限修改'));
    		}
            if ($v->validates())
            {
                $channel_id = post('channel_id', null);
                $orm = new \Db\Mall\Channel($channel_id);
                
                $orm->channel_name = post('channel_name');
                $orm->category_id = post('category_id');
                $orm->merchant_id = post('merchant_id');
                $orm->merchant_key = post('merchant_key');
                $orm->public_key = post('public_key');
                $orm->private_key = post('private_key');
                $orm->platform_id = post('platform_id', '');
                $orm->channel_order = post('channel_order');
                $orm->channel_status = post('channel_status', 0);
                $orm->client_type = post('client_type', 0);
                $orm->channel_remark = post('channel_remark', '');
                $orm->channel_host = post('channel_host', '');
                $orm->create_time = time();
                $orm->category_type = $category_type;
                
                $orm->media_id = post('media_ids', '');
                
                $orm->save();
                $v->append_data(array('url'=>"/manage/channel?category_type={$category_type}"));
            }
        }
        $v->send();
    }
}