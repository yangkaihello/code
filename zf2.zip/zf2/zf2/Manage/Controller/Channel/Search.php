<?php
namespace Manage\Controller\Channel;

class Search extends \Manage\Password
{
    
    public function get()
    {
        $key = get('key');
        $where[] = "channel_name like '{$key}%'";
        $rows = \Db\Mall\Channel::fetch($where, 10, 0);
        $data = array();
        foreach ($rows as $row) 
        {
            $data[] = array('value' => $row->channel_name.'-'.$row->category->category_name, 'id' => $row->channel_id);
        }
        echo json_encode($data);
        
    }
}