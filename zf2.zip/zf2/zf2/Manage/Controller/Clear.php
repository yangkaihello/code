<?php
namespace Manage\Controller;

class Clear extends \Manage\Password
{
    
    public function get()
    {
        $admin = self::login_admin();
        $this->title = '清除记录';
        $this->content = new \Micro\View('Manage/Clear');
        $get = get();
        $v = new \Even\Validation($get);
        
        $page = get('page', 1);
        $key = get('key', '');
        $limit = 10;
        $offset = ($page -1)*$limit;

        $filter = get('filter', 'wait');
        
        
        $where = array();
        if($filter == 'wait')
        {
            $where['recharge_status'] = 1;
            $where['pay_status'] = 0;
        }
        elseif($filter == 'success')
        {
            $where['recharge_status'] = 1;
            $where['pay_status'] = 1;
        }
        elseif($filter == 'check')
        {
            $where['recharge_status'] = 2;
            $where['pay_status'] = 1;
        }
        

        $merchant_id = get('merchant_id', 'all');
        if($merchant_id != 'all')
        {
            $where['merchant_id'] = $merchant_id;
        }
        
        $time_start = get('time_start', '');
        if(!empty($time_start))
        {
             $time_start = strtotime($time_start);
             $v->append_data(array('time_start'=>$time_start));
             $where[2] = "create_time > $time_start";
        }
        $time_end = get('time_end', '');
        if(!empty($time_end))
        {
             $time_end = strtotime($time_end);
             $v->append_data(array('time_end'=>$time_end));
             $where[3] = "create_time < $time_end";
        }
        
        if(!empty($key))
        {
            $len = mb_strlen($key);
            if($len == 14 && is_numeric($key))
            {
                $where['recharge_id'] = $key;
            }
            elseif($len > 14)
            {
                $where['transaction_id'] = $key;
            }
            else
            {
                $where[4] = "user_account like '{$key}%'";
            }
        }
        $this->content->channels = \Db\Mall\Channel::fetch();
        $this->content->count_amount = \Db\Account\Recharge::sum($where, 'total_amount');
        $this->content->rows = \Db\Account\Recharge::fetch($where, $limit, $offset, array('create_time'=>'desc'));
        $this->content->page = new \Manage\Model\Pagination(\Db\Account\Recharge::count($where), $page, $limit, '/manage/clear', $get);
        $this->content->v = $v;
        $this->content->admin = $admin;
        $this->send();
    }
    
    public function delete()
    {
        $admin = self::login_admin();
        $delete = \delete();
        
        $v = new \Even\Validation($delete);
        if($admin->admin_level > 0)
        {
            $v->append_error(array('message'=>'您没有权限修改'));
        }
        if($v->validates())
        {
            $key = $delete['key'];
            $where = array();
            
            $filter = !empty($delete['filter']) ? $delete['filter'] : 'check';
            
            
            $where = array();
            if($filter == 'wait')
            {
                $where['recharge_status'] = 1;
                $where['pay_status'] = 0;
            }
            elseif($filter == 'success')
            {
                $where['recharge_status'] = 1;
                $where['pay_status'] = 1;
            }
            elseif($filter == 'check')
            {
                $where['recharge_status'] = 2;
                $where['pay_status'] = 1;
            }
            
            
            $merchant_id = !empty($delete['merchant_id']) ? $delete['merchant_id'] : 'all';
            
            if($merchant_id != 'all')
            {
                $where['merchant_id'] = $merchant_id;
            }
            
            $time_start = !empty($delete['time_start']) ? $delete['time_start'] : '';
            if(!empty($time_start))
            {
                 $time_start = strtotime($time_start);
                 $v->append_data(array('time_start'=>$time_start));
                 $where[2] = "create_time > $time_start";
            }
            $time_end = !empty($delete['time_end']) ?  $delete['time_end'] : '';
            if(!empty($time_end))
            {
                 $time_end = strtotime($time_end);
                 $v->append_data(array('time_end'=>$time_end));
                 $where[3] = "create_time < $time_end";
            }
            
            if(!empty($key))
            {
                $len = mb_strlen($key);
                if($len == 14 && is_numeric($key))
                {
                    $where['recharge_id'] = $key;
                }
                elseif($len > 14)
                {
                    $where['transaction_id'] = $key;
                }
                else
                {
                    $where[4] = "user_account like '{$key}%'";
                }
            }
			if(!empty($where))
			{
            	$condition = \Db\Account\Recharge::$db->where($where);
            	$sql = "DELETE FROM vs_account_recharge WHERE $condition[0]";
			}
			else
			{
				$condition[1] = null;
            	$sql = "DELETE FROM vs_account_recharge";
			}
            $count = \Db\Account\Recharge::$db->delete($sql, $condition[1]);
            $v->append_data(array('count'=>$count));
        }
        $v->send();
    }
}