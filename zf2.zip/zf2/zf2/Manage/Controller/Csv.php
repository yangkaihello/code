<?php
/**
 * 导出财务流水
 */
namespace Manage\Controller;

class Csv extends \Manage\Password
{
    
    public function get()
    {        
        $key = get('key', '');
        $get = get();
        $v = new \Even\Validation($get);
        $where = array();
        
        $filter = get('filter', 'success');
        
        
        $where = array();
        if($filter == 'wait')
        {
            $where['recharge_status'] = 1;
            $where['pay_status'] = 0;
        }
        elseif($filter == 'success')
        {
            $where['recharge_status'] = 1;
            $where['pay_status'] = 1;
        }
        elseif($filter == 'check')
        {
            $where['recharge_status'] = 2;
            $where['pay_status'] = 1;
        }
        elseif($filter == 'all')
        {
            $where[0] = "recharge_status > 0";
        }
        
        
        $merchant_id = get('merchant_id', 'all');
        if($merchant_id != 'all')
        {
            $where['merchant_id'] = $merchant_id;
        }
        
        $time_start = get('time_start', '');
        if(!empty($time_start))
        {
             $time_start = strtotime($time_start);
             $v->append_data(array('time_start'=>$time_start));
             $where[2] = "create_time > $time_start";
        }
        $time_end = get('time_end', '');
        if(!empty($time_end))
        {
             $time_end = strtotime($time_end);
             $v->append_data(array('time_end'=>$time_end));
             $where[3] = "create_time < $time_end";
        }
        
        if(!empty($key))
        {
            $len = mb_strlen($key);
            if($len == 14 && is_numeric($key))
            {
                $where['recharge_id'] = $key;
            }
            elseif($len > 14)
            {
                $where['transaction_id'] = $key;
            }
            else
            {
                $where[4] = "user_account like '{$key}%'";
            }
        }
        
        $rows = \Db\Account\Recharge::fetch($where, 0, 0, array('create_time'=>'desc'));
        //var_dump($rows);exit();
        $excel = new \SimpleExcel\SimpleExcel('CSV');
        $excel->writer->addRow(array('系统单号', '平台流水', '支付平台', '商户号', '客户端', '账号', '金额', '创建时间', '回调时间', '核销时间', '支付状态', '处理状态', '操作者'));
        foreach ($rows as $row)
        {
            $data = array(
                $row->recharge_id, 
                $row->transaction_id, 
                !empty($row->channel->channel_name) ? $row->channel->channel_name : '', 
                $row->merchant_id, 
                $row->get_client_type(), 
                $row->user_account, 
                $row->total_amount, 
                $row->get_create_time(), 
                $row->get_time_pay(), 
                $row->get_time_verification(), 
                strip_tags($row->get_pay_status()), 
                strip_tags($row->get_recharge_status()),
                $row->op_name,
            );
            $excel->writer->addRow($data);
        }
        $excel->writer->saveFile(time());
        
    }
    
}