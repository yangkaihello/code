<?php
namespace Manage\Controller;

class Getway extends \Manage\MyController
{
    public function get()
    {
        redirect(site_url('/'));
    }
    
    /**
     * 登录
     */
    public function post()
    {
        $account =  post('admin_account');
        $password = post('admin_password');
        $v = new \Even\Validation($_POST);
        $v->field('user_account')->email('邮箱格式错误');
		$ip_list =  \Db\Configure::get_kv('ip_list');
		$ip_list_arr = explode(',', $ip_list);
		if(!empty($ip_list_arr[0]))
		{
			if(!in_array($_SERVER["REMOTE_ADDR"], $ip_list_arr))
			{
				$v->append_error(array('message'=>'无权访问'));
			}
		}
        if ($v->validates())
        {
            $gen_password = \Db\Authorize\Admin::gen_password($password);
            $row = \Db\Authorize\Admin::row(array('admin_account'=>$account, 'admin_password'=>$gen_password));
            if (!empty($row->admin_account))
            {
                \Db\Log::message('登录', client_ip(), $row->admin_name);
                $_SESSION['admin_id'] =  $row->admin_id;
                $token = md5(time());
                \Even\Cache::load_config();
                \Even\Cache::set('login_id_'.$row->admin_id, $token);
                $_SESSION['token'] = $token;
                \Micro\Session::save();
                redirect(site_url('manage/rechargeone'));
            }
            else 
            {
                $v->append_error(array('message'=>'帐号或密码错误'));
                redirect(site_url('/'));
            }
        }
        $v->send();
    }
    
    /**
     * 退出登录
     */
    public function delete()
    {
        $admin = \Manage\Password::login_admin();
        
        \Db\Log::message('退出', client_ip(), $admin->admin_name);
        \Micro\Session::destroy();
    }
}