<?php
namespace Manage\Controller;

class Helpcenter extends \Manage\Password
{
    
    public function get()
    {
        $this->title = '帮助中心';
        $this->content = new \Micro\View('Manage/Helpcenter');
        
        $page = get('page', 1);
        $limit = 10;
        $offset = ($page -1)*$limit;
        $where = array();
         /*$this->content->rows = \Db\Configure::fetch($where, $limit, $offset, array('configure_id'=>'desc'));*/
        $this->content->page = new \Manage\Model\Pagination(\Db\Configure::count($where), $page, $limit, '/manage/helpcenter');
        $this->send();
    }
}