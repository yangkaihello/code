<?php
namespace Manage\Controller;
/**
 * 获取素材文件
 * @author EVEN
 *
 */
class Image extends \Manage\MyController
{
	/**
	 * 获取任意尺寸图片
	 * demo:
	 * http://cw.vstry.com/image?path=/upload/1440605685.jpg&w=350&h=150
	 */
    public function get()
    {
    	$path = get('path');
    	$w = get('w', 0);
    	$h = get('h', 0); 
    	$file = SP . 'Public'.$path;
    	
    	//var_dump(is_file($file));exit();
        $url_path = \Even\GD::thumbnail($file, $w, $h);
        if(!empty($url_path))
        {
            redirect($url_path);
        }
        header("status: 404 Not Found");
    }
    
    /**
     * http://cw.vstry.com/image/get?path=/upload/1440605685.jpg&size=350-150
     * @param unknown_type $path
     * @param unknown_type $width
     * @param unknown_type $height
     */
    public static function url($path, $w, $h)
    {
        echo site_url('image', array('path'=>$path, 'w'=>$w, 'h'=>$h));
    }
}