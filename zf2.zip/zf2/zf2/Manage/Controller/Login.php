<?php
namespace Manage\Controller;

class Login extends \Manage\MyController
{
    public $template = 'Manage/Login';
    
    /**
     * 输出界面
     */
    public function get()
    {
    	$ip_list =  \Db\Configure::get_kv('ip_list');
		$ip_list_arr = explode(',', $ip_list);
		if(!empty($ip_list_arr[0]))
		{
			if(in_array($_SERVER["REMOTE_ADDR"], $ip_list_arr))
			{
				$this->send();
			}
			else
			{
				redirect(site_url('/'));
			}
		}
		else
		{
        	$this->send();
		}
    }
}