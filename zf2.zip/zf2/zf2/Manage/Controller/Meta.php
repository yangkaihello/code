<?php
namespace Manage\Controller;

class Meta extends \Manage\Password
{
    public function post()
    {
        $v = new \Manage\Model\Validation($_POST);
        $dir = 'upload/';
        $upload = new \Micro\Upload();
        $name = $upload->file($_FILES['file'], SP.'Public/'.$dir);
        if($name)
        {
            $media = new \Db\Media();
            $media->media_url = '/'.$dir.$name;
            $media->media_status = 1;
            $media->create_time = time();
            $media->media_type = 0;
            $media->save();
            $v->append_data(array('imgurl'=>'/'.$dir.$name, 'id'=>$media->media_id));
        }
        else 
        {
            $v->append_error(array('message'=>'上传处理失败'));
        }
        $v->send();
    }
}