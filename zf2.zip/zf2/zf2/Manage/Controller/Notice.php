<?php
namespace Manage\Controller;

class Notice extends \Manage\Password
{
    
    public function get()
    {
        $get = get();
        $v = new \Even\Validation($get);
        $where = array('recharge_status'=>1, 'pay_status'=>1);
        $rows = \Db\Account\Recharge::fetch($where, 10, 0, array('create_time'=>'asc'));
        if(!empty($rows))
        {
            $view = new \Micro\View('Manage/Notice');
            $view->rows = $rows;
            $v->append_data(array('count'=>count($rows), 'tpl'=>$view->__toString()));
        }
        else
        {
            $v->append_error(array('message'=>'没有更多了...'));
        }
        $v->send();
    }
}