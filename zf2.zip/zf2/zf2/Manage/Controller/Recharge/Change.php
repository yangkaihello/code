<?php
namespace Manage\Controller\Recharge;

class Change extends \Manage\Password
{
    /**
     * 更改订单状态
     */
    public function post()
    {
        $admin = self::login_admin();
        $recharge_id = post('recharge_id');
        $pay_status = post('pay_status', 1);
        $action = post('action','rechargeone');
        $orm = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id));
        $v = new \Manage\Model\Validation($_POST);
       
        if(empty($orm))
        {
            $v->append_error(array('message'=>'订单不存在'));
        }
        //if(empty($orm->recharge_remark))
        //{
        //    $v->append_error(array('message'=>'请先添加备注'));
        //}
        if($admin->admin_level != 0 && $admin->admin_level != 1)
        {
            $v->append_error(array('message'=>'您没有权限'));
        }
        if($v->validates())
        {
        	$orm->pay_status = 1;
        	$orm->op_name = $admin->admin_name;
        	$orm->save();
        	$v->append_data(array('url'=>site_url("/manage/{$action}", array('filter'=>'all', 'key'=>$recharge_id))));
        }
        $v->send();
    }
}