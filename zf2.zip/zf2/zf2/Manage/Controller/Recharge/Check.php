<?php
namespace Manage\Controller\Recharge;

class Check extends \Manage\Password
{
    /**
     * 批量核销订单
     */
    public function post()
    {
        $admin = self::login_admin();
        $v = new \Manage\Model\Validation($_POST);
        $action = post('action','rechargeone');

        if($admin->admin_level != 0)
        {
            $v->append_error(array('message'=>'您没有权限操作'));
        }
        
        if($v->validates())
        {
            $time = START_TIME - 600;
            $where = array('create_time' < $time);
            $db = \Db\Account\Recharge::$db;
            $db->update(static::$table, $data, array(static::$key => $this->data[static::$key]));
        	$v->append_data(array('url'=>site_url("/manage/{$action}", array('filter'=>'all'))));
        }
        $v->send();
    }
}