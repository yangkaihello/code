<?php
namespace Manage\Controller\Recharge\Qrauto;

class Tohandle extends \Manage\Password
{
    /**
     * 获取用户填写待处理的订单
     */
    public function get()
    {
        $admin = self::login_admin();
        
        $category_name = get('category_name','alipay');

        $return = array('handle'=>'');
        
        $v = new \Manage\Model\Validation(get());
        if($admin->admin_level != 0 && $admin->admin_level != 1)
        {
            $v->append_error(array('message'=>'您没有权限'));
        }
        if($v->validates())
        {
            $row = \Db\Account\Recharge\Qrauto\User::row(array('status'=>0,'category_name'=>$category_name));
            if(!empty($row)) {
                $return['handle'] = array(
                    'id'=>$row->id,
                    'user_account'=>$row->user_account,
                    'total_amount'=>$row->total_amount,
                    'transaction_id'=>$row->transaction_id,
                );
            }
        }
        $v->append_data($return);
        $v->send();
        
        /*$categorys = \Db\Mall\Category::fetch(array('category_type'=>2));
        foreach ($categorys as $value) {
            if ($value->category_name == $category_name)
            {
                $category_id = $value->category_id;
            }
        }
        $channels = \Db\Mall\Channel::fetch(array('category_type'=>2));
        $temp_channels = array();
        foreach($channels as $temp) {
            if($temp->category_id == $category_id) {
                $temp_channels[] = $temp->channel_id;
            }
        }
        $where = array();
        if($temp_channels) {
            $where[] = "channel_id IN(".implode(',', $temp_channels).")";
        }
        $where[] = 'pay_status=0';
        $where[] = 'recharge_id NOT IN(SELECT recharge_id FROM vs_account_recharge_qrauto)';
        
        $sql = 'SELECT recharge_id,user_account,total_amount,create_time FROM vs_account_recharge where '.implode(' AND ', $where).' ORDER BY recharge_id ASC LIMIT 1';
        
        $data = array();
        foreach(\Db\Mall\Channel::$db->fetch($sql) as $row) {
            $data = (array)$row;
        }
       
        $v = new \Manage\Model\Validation(get());
        if($admin->admin_level != 0 && $admin->admin_level != 1)
        {
            $v->append_error(array('message'=>'您没有权限'));
        }
        if($v->validates())
        {
        	$v->append_data(array('recharge'=>$data));
        }
        $v->send();*/
    }
    
    //处理订单
    public function post() {
        $admin = self::login_admin();
        $postData = (array)@json_decode(post('postData'),true);
        
        $v = new \Manage\Model\Validation($_POST);
        
        $time = time();
        $return = array('code'=>0,'flist'=>array(),'slist'=>array());
        //var_dump($postData);die;
        foreach($postData as $r) {
            if(isset($r['user_post_id']) && $r['user_post_id']) { // 用户填写订单处理
                if(isset($r['not_found'])) {
                    $status = 2; //没找到记录
                } else {
                    $ormQrauto = \Db\Account\Recharge\Qrauto::row(array('transaction_id'=>$r['transaction_id']));
                    $status = 1;
                    if(!empty($ormQrauto)) { //流水号被使用
                        $status = 2;
                    }
                }
                $ormUser = \Db\Account\Recharge\Qrauto\User::row(array('id'=>$r['user_post_id']));
                $ormUser->category_name = $r['category_name'];
                //$ormUser->user_account = $r['user_account'];
                $ormUser->handle_time = $time;
                $ormUser->status = $status;
                $ormUser->save();
                if($status == 1) { //生成充值记录
                    $recharge_id = \Db\Account\Recharge::gen_recharge_id();
                    $recharge = new \Db\Account\Recharge();
                    $recharge = $recharge->gen_new_recharge2(1, $recharge_id, $ormUser->user_account, $ormUser->total_amount, '', 0, $r['category_name'],'',"{$ormUser->user_account}_{$recharge_id}",1);
                    
                    $ormQrauto = new \Db\Account\Recharge\Qrauto();
                    $ormQrauto->add(array(
                    	'transaction_id'=> $r['transaction_id'],
                    	'user_account'=> $ormUser->user_account,
                        'recharge_id'=>$recharge_id,
                        'category_name'=>$r['category_name'],
                        'pay_time'=> $r['pay_time'],
                    ));
                }
            } else {
                $ormQrauto = \Db\Account\Recharge\Qrauto::row(array('transaction_id'=>$r['transaction_id']));
                if(!empty($ormQrauto)) { //流水号被使用
                    $return['flist'][] = $r['transaction_id'];
                    continue;
                }
                $recharge_id = \Db\Account\Recharge::gen_recharge_id();
                $recharge = new \Db\Account\Recharge();
                $recharge = $recharge->gen_new_recharge2(1, $recharge_id, $r['user_account'], $r['total_amount'], '', 0, $r['category_name'],'',"{$r['user_account']}_{$recharge_id}",1);
                
                $ormQrauto = new \Db\Account\Recharge\Qrauto();
                $ormQrauto->add(array(
                	'transaction_id'=> $r['transaction_id'],
                	'user_account'=> $r['user_account'],
                    'recharge_id'=>$recharge_id,
                    'category_name'=>$r['category_name'],
                    'pay_time'=> $r['pay_time'],
                ));
                $return['slist'][] = $r['transaction_id'];
            }
        }
        
        $v->append_data($return);
        $v->send();
        /*$admin = self::login_admin();
        $recharge_id = post('recharge_id');
        $pay_status = post('pay_status', 0);
        $category_name = post('category_name', 0);
        $status = post('status', 0);
        $orm = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id));
        $orm1 = \Db\Account\Recharge\Qrauto::row(array('recharge_id'=>$recharge_id));
        $v = new \Manage\Model\Validation($_POST);
       
        if(empty($orm))
        {
            $v->append_error(array('message'=>'订单不存在'));
        }
        elseif(!empty($orm1)) {
            $v->append_error(array('message'=>'订单已处理'));
        }
        if($admin->admin_level != 0 && $admin->admin_level != 1)
        {
            $v->append_error(array('message'=>'您没有权限'));
        }
        if($v->validates())
        {
            if($pay_status == 1) {
            	$orm->pay_status = 1;
            	$orm->op_name = $admin->admin_name;
            	$orm->save();
            }
            $orm1->category_name = $category_name;
            $orm1->create_time = time();
            $orm1->status = $status;
            $orm1->save();
        	$v->append_data();
        }
        $v->send();*/
    }
}