<?php
namespace Manage\Controller\Recharge\Qrauto;

class User extends \Manage\Password
{
    //用户手动输入账号列表
    public function get(){
        $admin = self::login_admin();
        $this->title = '用户提交记录';
        $this->content = new \Micro\View('Manage/Recharge/Qrauto/User');
        $limit = 50;
        $page = get('page', 1);
        $key = get('key', '');
        $offset = ($page -1)*$limit;
        $this->content->rows = \Db\Account\Recharge\Qrauto\User::fetch(array(), $limit, $offset, array('create_time'=>'desc'));
        //var_dump($where);exit();
        $get = get();
        $this->content->page = new \Manage\Model\Pagination(\Db\Account\Recharge\Qrauto\User::count(array()), $page, $limit, '/manage/recharge/qrauto/user', $get);
        //$this->content->v = $v;
        $this->content->admin = $admin;
        $this->send();
    }
    
    /**
     * 处理流水号订单
     */
    public function post()
    {
        $admin = self::login_admin();
        
        $transaction_id = post('transaction_id','');
        $recharge_id = post('recharge_id','');
        $user_account = post('user_account','');
        $category_name = post('category_name','alipay');
        $status = post('status',0);
        $pay_time = post('pay_time',0);
        $not_found = post('not_found',0);
        
        $v = new \Manage\Model\Validation(get());
        $data = array(
        	'used'=>false,
            'success'=>false,
        );
        if($admin->admin_level != 0 && $admin->admin_level != 1)
        {
            $v->append_error(array('message'=>'您没有权限'));
        } elseif ($not_found) {
            $orm = new \Db\Account\Recharge\Qrauto();
                $orm->add(array(
                    'recharge_id'=>$recharge_id,
                    'category_name'=>$category_name,
                	'create_time'=> time(),
                    'status'=>0,
                    'transaction_id'=> '',
                    'pay_time'=> '',
                ));
        } elseif (!$transaction_id || !$recharge_id || !$user_account) {
           $v->append_error(array('message'=>'参数错误')); 
        } else {
            $Qrauto = \Db\Account\Recharge\Qrauto::fetch(array('transaction_id'=>$transaction_id));
            if(!empty($Qrauto)) {
                $data['used'] = true;
            } else { //
                $orm = new \Db\Account\Recharge\Qrauto();
                $orm->add(array(
                    'recharge_id'=>$recharge_id,
                    'category_name'=>$category_name,
                	'create_time'=> time(),
                    'status'=>$status,
                    'transaction_id'=> $transaction_id,
                    'pay_time'=> $pay_time,
                ));
                
                $orm1 = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id));
                if($orm1->pay_status == 0) {
                    $orm1->pay_status = 1;
                    $orm1->transaction_id = $transaction_id;
	                $orm1->time_pay = time();
                    $orm1->save();
                }
                $data['success'] = true;
            }
        }
        
        $v->append_data($data);
        $v->send();
    }
    
}