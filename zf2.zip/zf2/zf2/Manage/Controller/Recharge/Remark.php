<?php
namespace Manage\Controller\Recharge;

class Remark extends \Manage\Password
{
    /**
     * 备注订单
     */
    public function post()
    {
        $admin = self::login_admin();
        $recharge_id = post('recharge_id');
        $recharge_remark = post('recharge_remark');
        $action = post('action','rechargeone');
        $orm = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id));
        $v = new \Manage\Model\Validation($_POST);
       
        if(empty($orm))
        {
            $v->append_error(array('message'=>'订单不存在'));
        }
        if($v->validates())
        {
        	$orm->recharge_remark = $recharge_remark;
        	$orm->op_name = $admin->admin_name;
        	$orm->save();
			$v->append_data(array('url'=>site_url("/manage/{$action}", array('filter'=>'all', 'key'=>$recharge_id))));
        }
		else
		{
			$v->append_data(array('url'=>site_url("/manage/{$action}", array('filter'=>'success'))));
		}
        $v->send();
    }
}