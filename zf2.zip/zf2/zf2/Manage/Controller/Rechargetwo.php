<?php
namespace Manage\Controller;

class Rechargetwo extends \Manage\Password
{
    
    public function get()
    {
        $admin = self::login_admin();
        $this->content = new \Micro\View('Manage/Rechargetwo');
        $get = get();
        $v = new \Even\Validation($get);
        
        $page = get('page', 1);
        $key = get('key', '');
        $category = get('category','wx');
        $paykey = trim(get('paykey', ''));
        $limit = 100;
        $offset = ($page -1)*$limit;

        if ($category == "wx") {
            $this->title = '微信充值记录';
        } else if($category == "alipay") {
            $this->title = '支付宝充值记录';
        } else if($category == "jd") {
            $this->title = '京东充值记录';
        } else {
            $this->title = '百度充值记录';
        }

        $filter = get('filter', 'all');
        
        $categorys = \Db\Mall\Category::fetch(array('category_type'=>2));
        foreach ($categorys as $value) {
            if ($value->category_name == $category)
            {
                $category_id = $value->category_id;
            }
        }
        $channels = \Db\Mall\Channel::fetch(array('category_type'=>2));
        $temp_channels = array();
        foreach($channels as $temp) {
            if($temp->category_id == $category_id) {
                $temp_channels[] = $temp->channel_id;
            }
        }
        $where = array();
        if($temp_channels) {
            $where[0] = "channel_id IN(".implode(',', $temp_channels).")";
        }
        //var_dump($category_id,$where);exit();
        if($filter == 'wait')
        {
            $where['recharge_status'] = 1;
            $where['pay_status'] = 0;
        }
        elseif($filter == 'success')
        {
            $where['recharge_status'] = 1;
            $where['pay_status'] = 1;
        }
        elseif($filter == 'check')
        {
            $where['recharge_status'] = 2;
            $where['pay_status'] = 1;
        }
        elseif($filter == 'all')
        {
            $where[1] = "recharge_status > 0";
        }
        

        $channel_id = get('channel_id', 'all');
        if($channel_id != 'all')
        {
            $where['channel_id'] = $channel_id;
        }
        
        $time_start = get('time_start', '');
        if(!empty($time_start))
        {
             $time_start = strtotime($time_start);
             $v->append_data(array('time_start'=>$time_start));
             $where[2] = "create_time > $time_start";
        }
        $time_end = get('time_end', '');
        if(!empty($time_end))
        {
             $time_end = strtotime($time_end);
             $v->append_data(array('time_end'=>$time_end));
             $where[3] = "create_time < $time_end";
        }
        if(!empty($key))
        {
            $len = mb_strlen($key);
            if($len == 14 && is_numeric($key))
            {
                $where['recharge_id'] = $key;
            }
            elseif($len > 14)
            {
                $where['transaction_id'] = $key;
            }
            else
            {
                $where[4] = "user_account like '{$key}%'";
            }
        }
        if(!empty($paykey))
        {
            $where[5] = "payment_account like '{$paykey}%'";
        }
        //var_dump($where);exit();
        $this->content->channels = $channels;
        $this->content->count_amount = \Db\Account\Recharge::sum($where, 'total_amount');
        $this->content->rows = \Db\Account\Recharge::fetch($where, $limit, $offset, array('create_time'=>'desc'));
        //var_dump($where);exit();
        $this->content->page = new \Manage\Model\Pagination(\Db\Account\Recharge::count($where), $page, $limit, '/manage/rechargetwo', $get);
        $this->content->v = $v;
        $this->content->admin = $admin;
        $this->send();
    }
    
    public function post()
    {
    	$admin = self::login_admin();
        $recharge_id = post('recharge_id');
        $orm = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id));
        $v = new \Manage\Model\Validation($_POST);
       
        if(empty($orm))
        {
            $v->append_error(array('message'=>'订单不存在'));
        }
        if($v->validates())
        {
            if($orm->pay_status !=1 )
            {
                $v->append_error(array('message'=>'未支付订单不能核销'));
            }
            if($orm->recharge_status == 2)
            {
                $v->append_error(array('message'=>'订单已核销'));
            }
            if($v->validates())
            {
                $orm->recharge_status = 2;
				$orm->op_name = $admin->admin_name;
                $orm->time_verification = time();
                $orm->save();
            }
        }
        $v->send();
    }
    
    public function delete()
    {
        $admin = self::login_admin();
        $delete = \delete();
        $v = new \Even\Validation($delete);
        $recharge_id = !empty($delete['recharge_id'])  ? $delete['recharge_id'] : '';
        if($admin->admin_level > 0)
        {
            $v->append_error(array('message'=>'您没有权限修改'));
        }
        
        $orm = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id));
        if(empty($orm))
        {
            $v->append_error(array('message'=>'记录不存在'));
        }
        if($v->validates())
        {
            $orm->recharge_status = 0;
            $orm->op_name = $admin->admin_name;
            $orm->time_delete = time();
            $orm->save();
        }
        $v->send();
    }
}