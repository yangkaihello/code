<?php
namespace Manage\Controller;

class Slide extends \Manage\Password
{
    
    public function get()
    {
        $this->title = '幻灯片';
        $this->content = new \Micro\View('Manage/Slide');
        
        $page = get('page', 1);
        $limit = 10;
        $offset = ($page -1)*$limit;
        $where = array();
        $this->content->rows = \Db\Slide::fetch($where, $limit, $offset, array('slide_order'=>'desc'));
        $this->content->page = new \Manage\Model\Pagination(\Db\Slide::count($where), $page, $limit, '/manage/slide');
        $this->send();
    }
    
    public function delete()
    {
        $slide_id = delete('slide_id');
        $orm = \Db\Slide::row(array('slide_id'=>$slide_id));
        if(!empty($orm))
        {
            $orm->delete();
        }
    }
}