<?php
namespace Manage\Controller\Slide;

class Edit extends \Manage\Password
{
    
    public function get()
    {
        $slide_id = get('slide_id');
        $this->title = '幻灯片';
        $this->content = new \Micro\View('/Manage/Slide/Edit');
        $this->content->row = \Db\Slide::row(array('slide_id'=>$slide_id));
        $this->send();
    }
    
}