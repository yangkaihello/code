<?php
namespace Manage\Controller\Slide;

class Save extends \Manage\Password
{
    
    public function get()
    {
        $this->title = '幻灯片';
        $this->content = new \Micro\View('/Manage/Slide/Save');
        $this->send();
    }
    
    public function post()
    {
        $v = new \Even\Validation($_POST);
        
        $v->field('slide_title')->required('必须填写标题');
        $v->field('slide_link')->required('必须填写链接地址');
        $v->field('slide_remark')->required('必须填写标签');
        $v->field('media_ids')->required('必须上传一张图片');

        $media_ids = explode(',', trim($_POST['media_ids'], ','));
        $pic = \Db\Media::row(array('media_id'=>$media_ids[0]));
        
        if(empty($pic))
        {
            $v->append_error(array('message'=>'图片不存在'));
        }
        if ($v->validates())
        {
            $slide_id = post('slide_id', null);
            $orm = new \Db\Slide($slide_id);
            
            $orm->slide_title = post('slide_title');
            $orm->slide_link = post('slide_link');
            $orm->slide_target = post('slide_target', '_self');
            $orm->slide_order = post('slide_order', 0);
            $orm->slide_pic = $pic->media_url;
            $orm->media_ids = serialize($media_ids);
            $orm->slide_remark = post('slide_remark');
            $orm->create_time = time();
            $orm->save();
            $v->append_data(array('url'=>'/manage/slide'));
        }
        $v->send();
    }
}