<?php
namespace Manage\Model;

class Menu
{
    public static function strpos($str)
    {
        return is_int(strpos(PATH, $str));
    }
}