<?php
namespace Manage\Model;

class Pagination extends \Micro\Pagination
{
    public $params = array();
    
    public $total_record = 0;
    
    public $attributes = array('class' => 'pagination pagination-sm no-margin', 'id' => 'pagination');
    
    /**
     * Creates pagination links for the total number of pages
     *
     * @param int $total number of items
     * @param int $current page
     * @param int $per_page the number to show per-page (default 10)
     * @param string $path to place in the links
     * @return string
     */
    public function __construct($total, $current, $per_page = 10, $path = NULL, $params = NULL)
    {
        $this->total_record = $total;
        $this->current = (int) $current;
        $this->per_page = (int) $per_page;
        $this->total = (int) ceil($total / $per_page);
        $this->path = $path;
        // Assume the current URL parameters if not given
        if(!empty($params))
        {
            $this->params = $params;
        }
    }
    
    public function __toString()
    {
        try
        {
            // Start and end must be valid integers
            $start = (($this->current - $this->links) > 0) ? $this->current - $this->links : 1;
            $end = (($this->current + $this->links) < $this->total) ? $this->current + $this->links : $this->total;
//             $html = \Micro\HTML::tag('li', '总数'.$this->total, array('class' => 'previous'));
            $html = \Micro\HTML::tag('li', \Micro\HTML::link($this->url($this->current), '总数'.$this->total_record, array('class' => 'previous')));
            $html .= $this->previous();
    
            for($i = $start; $i <= $end; ++$i)
            {
                // Current link is "active"
                $attributes = $this->current == $i ? array('class' => 'active') : array();
    
                // Wrap the link in a list item
                $html .= \Micro\HTML::tag('li', \Micro\HTML::link($this->url($i), $i), $attributes);
            }
    
            $html .= $this->next();
    
            return \Micro\HTML::tag('ul',  $html , $this->attributes);
        }
        catch(\Exception $e)
        {
            \Micro\Error::exception($e);
            return '';
        }
    
    }
    
    /**
     * Build the pagination URL
     *
     * @param integer $page number
     */
    public function url($page = NULL)
    {
        $params = array_merge($this->params , array('page' => $page));
        return $this->path.'?'.http_build_query($params);
    }
}