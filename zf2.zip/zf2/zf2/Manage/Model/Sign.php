<?php
namespace Manage\Model;

class Sign
{
    public static function generate_params($post_data, $key)
    {
        $sign = "";
        ksort($post_data);
        $post_str = urldecode(http_build_query($post_data));
        $sign = md5($post_str."&key=".$key);
        return $post_str."&sign=".$sign;
    }
    
    public static function post($post_data, $key)
    {
        $host = 'https://pay.41.cn/remit';
        $query = self::generate_params($post_data, $key);
        $info = \Even\Curl::post($host, $query);
        return $info->response;
    }
    
    public static function query($post_data, $key)
    {
        $host = 'https://pay.41.cn/remit/balance';
        $query = self::generate_params($post_data, $key);
        $info = \Even\Curl::post($host, $query);
        var_dump($info);exit();
        return $info->response;
    }
}