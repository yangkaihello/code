<?php
namespace Manage\Model;

class Validation extends \Micro\Validation
{
    // Array of errors
    public $errors = array();
    
    /**
     * Return success if validation passes!
     *
     * @return boolean
     */
    public function validates()
    {
        return empty($this->errors);
    }
    
    /**
     * 验证手机号码
     *
     * @param string $data to validate
     * @return boolean
     */
    protected function mobile_rule($data)
    {
        return preg_match('/^1[34578]\d{9}$/', $data);
    }
    
    /**
     * 输入提示信息
     * @param arr $error
     * @return \Model\Validation
     */
    public function append_error($arr)
    {
        $this->errors = array_merge($this->errors,  $arr);
    
        return $this;
    }
    
    /**
     * 设置数据
     * @param array $arr
     */
    public function append_data($arr)
    {
        $this->data = array_merge($this->data, $arr);
    }
    
    /**
     * 获取错误消息
     */
    protected function format()
    {
        if($this->validates())
        {
            $data =  array('message'=> '', 'data'=>$this->data);
        }
        else 
        {
            $shift_message = array_shift($this->errors);
            $data =  array('message'=>$shift_message, 'data'=>array());
        }
        return $data;
    }
    
    /**
     * 输出数据
     */
    public function send()
    {
        \Micro\Session::save();
        header("Content-type: application/json");
        echo json_encode($this->format());
        exit();
    }
}