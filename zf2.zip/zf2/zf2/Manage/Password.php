<?php
namespace Manage;

class Password extends \Manage\MyController
{
    public static $admin = NULL;
    
    /**
     * Called after the controller is loaded, before the method
     *
     * @param string $method name
     */
    public function initialize($method)
    {
        parent::initialize($method);
        $admin = static::login_admin();
        if (empty($admin))
        {
            redirect(site_url('/'));
        }
        \Even\Cache::load_config();
        if(session('token', '1') != \Even\Cache::get('login_id_'.$admin->admin_id)) {
            redirect(site_url('/'));
        }
    }
    
    public static function login_admin()
    {
        if(empty(static::$admin))
        {
    	    $admin_id = session('admin_id', null);
    	    if(!empty($admin_id))
    	    {
    	        static::$admin = \Db\Authorize\Admin::row(array('admin_id'=>$admin_id));
    	    }
        }
        return static::$admin;
    }
    
    /**
	 * Save user session and render the final layout template
	 */
	public function send()
	{
		\Micro\Session::save();

		headers_sent() OR header('Content-Type: text/html; charset=utf-8');

		$layout = new \Micro\View($this->template);
		$layout->admin = self::$admin;
		$layout->set((array) $this);
		print $layout;
		
		$layout = NULL;

		if(config()->debug_mode)
		{
			print new \Micro\View('System/Debug');
		}
	}
}