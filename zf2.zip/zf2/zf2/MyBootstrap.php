<?php
require('Bootstrap.php');
function load_database($name = 'database')
{
	// Load database
	$db = new \Micro\Database(config()->$name);

	// Set default ORM database connection
	if(empty(\Micro\ORM::$db))
	{
		\Micro\ORM::$db = $db;
	}

	return $db;
}
load_database();
