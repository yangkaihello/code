<?php
require("help.php");
require_once realpath(__DIR__).'/../../../MyBootstrap.php';
//log_message('notice:'.var_export($_REQUEST, true));

$p1_MerId = $_REQUEST['p1_MerId'];

$r0_Cmd		= $_REQUEST['r0_Cmd'];
$r1_Code	= $_REQUEST['r1_Code'];
$r2_TrxId	= $_REQUEST['r2_TrxId'];
$r3_Amt		= $_REQUEST['r3_Amt'];
$r4_Cur		= $_REQUEST['r4_Cur'];
$r5_Pid		= $_REQUEST['r5_Pid'];
$r6_Order	= $_REQUEST['r6_Order'];
$r7_Uid		= $_REQUEST['r7_Uid'];
$r8_MP		= $_REQUEST['r8_MP'];
$r9_BType	= $_REQUEST['r9_BType']; 
$hmac		= $_REQUEST['hmac'];


$channel = \Db\Mall\Channel::row(array('merchant_id'=>$p1_MerId));
if(empty($channel) || $channel->channel_name != basename(__DIR__)){exit(0);}
$merchantKey = $channel->merchant_key;

$sign_md5 = getCallbackHmacString($p1_MerId, $merchantKey, $r0_Cmd, $r1_Code, $r2_TrxId, $r3_Amt, $r4_Cur, $r5_Pid, $r6_Order, $r7_Uid, $r8_MP, $r9_BType);



if($sign_md5 == $hmac)
{
    if($r1_Code=="1")
    {
        $trans_id = $r6_Order;
        $trans_part = explode('_', $trans_id);
        $account = $trans_part[0];
        $recharge_id = $trans_part[1];
        $recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id, 'pay_status'=>0));
        if(!empty($recharge) && $recharge->channel_name == basename(__DIR__))
        {
            $recharge->pay_status = 1;
            $recharge->transaction_id = $trans_id;
            $recharge->time_pay = time();
            $recharge->save();
        }
        
    }
}
if($r9_BType=="1")
{
    header("Location:http://{$_SERVER['SERVER_NAME']}");
}
elseif($r9_BType=="2") 
{
    echo "success";
}