<?php
require_once realpath(__DIR__).'/../../../MyBootstrap.php';

log_message('notice:'.var_export($_REQUEST, true));

$partner = $_REQUEST['partner'];
$ordernumber = $_REQUEST['ordernumber'];

$orderstatus = $_REQUEST['orderstatus'];
$paymoney = $_REQUEST['paymoney'];

$attach = $_REQUEST['attach'];
$sign = $_REQUEST['sign'];

$channel = \Db\Mall\Channel::row(array('merchant_id'=>$partner));
if(empty($channel) || $channel->channel_name != basename(__DIR__)){exit(0);}

$key = $channel->merchant_key;

$signSource = sprintf("partner=%s&ordernumber=%s&orderstatus=%s&paymoney=%s%s", $partner, $ordernumber, $orderstatus, $paymoney, $key); 
$md5Sign = md5($signSource);


if ($sign == $md5Sign)
{
    if ($orderstatus == 1)
    {
	    $trans_id = $ordernumber;
	    $trans_part = explode('_', $trans_id);
	    $account = $trans_part[0];
	    $recharge_id = $trans_part[1];
	    
	    $recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id, 'pay_status'=>0));
	    if(!empty($recharge) && $recharge->channel_name == basename(__DIR__))
	    {
	        $recharge->pay_status = 1;
	        $recharge->transaction_id = $recharge_id;
	        $recharge->time_pay = time();
	        $recharge->save();
	    } 
    }
}

echo 'ok';