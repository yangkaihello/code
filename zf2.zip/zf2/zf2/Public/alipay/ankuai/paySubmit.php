<?php
$gateway_url =  "http://pay.ankuaipay.cn/PayBank.aspx";

//用户ID
$partner = $merchant_id;
//用户key
$key = $merchant_key;

$ordernumber       = $order_no;
//$paymoney   = $coin;
/***
 * 安快通知：为了大家使用的更稳定，支付宝要求提交的金额不要整数，
麻烦去联系一下你们技术做一下提交订单随机后面多加两位小数点。谢谢配合！
比如：客户提交100 订单实际生成的支付的金额：100.11和100.05
 */
$paymoney   = $coin.'.'.str_pad(mt_rand(0, 10), 2, '0',STR_PAD_LEFT);
if(is_wap())
{
    $banktype = 'ALIPAYWAP';
}
else
{
    $banktype = 'ALIPAY';
}

$callbackurl     = 'http://'.$_SERVER['SERVER_NAME'].'/alipay/ankuai/payNotice.php';
$hrefbackurl     = 'http://'.$_SERVER['SERVER_NAME'].'/alipay/ankuai/payReturn.php';


$attach = $merchant_id;

$signSource = sprintf("partner=%s&banktype=%s&paymoney=%s&ordernumber=%s&callbackurl=%s%s", $partner, $banktype, $paymoney, $ordernumber, $callbackurl, $key);
$sign = md5($signSource);

?>

<!DOCTYPE html>
<html>
<head>
    <title>网关支付</title>
    <meta charset="utf-8">
</head>
<body>
    <form action="<?php echo $gateway_url?>" method="get">
	    <input type="hidden" id="partner" name="partner" value="<?php echo $partner; ?>"/>
	    <input type="hidden" id="ordernumber" name="ordernumber" value="<?php echo $ordernumber ?>" />
	    <input type="hidden" id="banktype" name="banktype" value="<?php echo $banktype; ?>" />
	    <input type="hidden" id="paymoney" name="paymoney" value="<?php echo $paymoney ?>" />
	    <input type="hidden" id="callbackurl" name="callbackurl" value="<?php echo $callbackurl ?>" />
	    <input type="hidden" id="hrefbackurl" name="hrefbackurl" value="<?php echo $hrefbackurl; ?>"  />
	    <input type="hidden"  id="attach" name="attach" value="<?php echo $attach ?>" />
	    <input type="hidden"  id="sign" name="sign" value="<?php echo "$sign"; ?>" />
    </form>
    <script type="text/javascript">
        document.forms[0].submit();
    </script>
</body>
</html>