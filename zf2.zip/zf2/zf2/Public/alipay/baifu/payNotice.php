<?php
//require("helper.php");
require_once realpath(__DIR__).'/../../../MyBootstrap.php';

//$postData = $_REQUEST;
////log_message('xinbao notice request='.var_export($postData, true));
$postData = trim(file_get_contents('php://input'));
//log_message('baifu notice postinput='.var_export($postData, true));

$xml = new SimpleXMLElement($postData);

if('SUCCESS' != $xml->return_code) {
    exit('FAIL');
} elseif('SUCCESS' != $xml->result_code) {
    exit('FAIL');
}

$params = array(
    'return_code'	    => $xml->return_code,	
    'return_msg'	    => $xml->return_msg,	
    'mch_id'	    => $xml->mch_id,	
    'nonce_str'	    => $xml->nonce_str,	
    //'sign'	    => $xml->sign,	
    'result_code'	    => $xml->result_code,	
    'err_code_des'	    => $xml->err_code_des,
    'trade_type'	    => $xml->trade_type,
    'total_fee'	    => $xml->total_fee,
    'fee_type'	    => $xml->fee_type,
    'cash_fee'	    => $xml->cash_fee,
    'cash_fee_type'	    => $xml->cash_fee_type,
    'coupon_fee'	    => $xml->coupon_fee,
    'coupon_count'	    => $xml->coupon_count,
    //'coupon_batch_id_$n'	    => $xml->coupon_count,
    //'coupon_id_$n'	    => $xml->coupon_count,
    //'coupon_fee_$n'	    => $xml->coupon_count,
    'transaction_id'	    => $xml->transaction_id,
    'third_trans_id'	    => $xml->third_trans_id,
    'out_trade_no'	    => $xml->out_trade_no,
    'time_end'	    => $xml->time_end,
);
for($i=0;$i<=1000;++$i) {
    $x = "coupon_batch_id_{$i}";
    if(!isset($xml->{$x})) break;
    $params[$x] = $xml->{$x};
}
for($i=0;$i<=1000;++$i) {
    $x = "coupon_id_{$i}";
    if(!isset($xml->{$x})) break;
    $params[$x] = $xml->{$x};
}
for($i=0;$i<=1000;++$i) {
    $x = "coupon_fee_{$i}";
    if(!isset($xml->{$x})) break;
    $params[$x] = $xml->{$x};
}

$channel = \Db\Mall\Channel::row(array('merchant_id'=>$params['mch_id']));
if(empty($channel) || $channel->channel_name != basename(__DIR__)){exit(0);}

$merchant_key = $channel->merchant_key;
$recharge1 = \Db\Account\Recharge::row(array('recharge_id'=>$params['out_trade_no']));

/* 排序并组装签名字符串 */
$arr = $params;
ksort($arr);
//$arr['key'] = $merchant_key;

$buff = "";
foreach ($arr as $x => $x_value){
	if($x_value != '' && !is_array($x_value)){
		$buff .= "{$x}={$x_value}&";
	}
}
$buff = rtrim($buff, "&")."&key={$merchant_key}";
$sign = strtoupper(md5($buff));

////log_message(var_export($params,true).' '.$sign);
$orderNo = $recharge1->user_account.'_'.$params['out_trade_no'];

if($sign == $xml->sign) {
    if('SUCCESS' == $xml->result_code)
    {
        $trans_id = $orderNo;
        $trans_part = explode('_', $trans_id);
        $account = $trans_part[0];
        $recharge_id = $trans_part[1];
        $recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id, 'pay_status'=>0));
        if(!empty($recharge) && $recharge->channel_name == basename(__DIR__))
        {
            $recharge->pay_status = 1;
            $recharge->transaction_id = $trans_id;
            $recharge->time_pay = time();
            $recharge->save();
            
            //log_message('notice success');
        }
        echo 'SUCCESS';
        exit(0);
    }
} else {
    //log_message('notice sign error');
}
echo 'FAIL';
