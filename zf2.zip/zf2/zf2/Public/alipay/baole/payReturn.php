<?php
require_once realpath(__DIR__).'/../../../MyBootstrap.php';


//$postData = trim(file_get_contents('php://input'));
$postData = $_REQUEST;
//log_message('baole notice postinput='.var_export($postData,true));

$recharge = \Db\Account\Recharge::row(array('recharge_id'=>$postData['orderid']));
if(empty($recharge)){exit(0);}
$channel = \Db\Mall\Channel::row(array('merchant_id'=>$recharge->merchant_id));
if(empty($channel) || $channel->channel_name != basename(__DIR__)){exit(0);}

$buff = 'orderid='.$postData['orderid'].'&opstate='.$postData['opstate'].'&ovalue='.$postData['ovalue'];
$sign = md5($buff.$channel->merchant_key);

$flag = $sign==$postData['sign'];
//log_message('check sign='.(int)$flag);

$OrderId = $recharge->user_account.'_'.$postData['orderid'];
if($flag)
{
    if(0 == $postData['opstate'])
    {
        $trans_id = $OrderId;
	    $trans_part = explode('_', $trans_id);
	    $account = $trans_part[0];
	    $recharge_id = $trans_part[1];
	    $recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id, 'pay_status'=>0));
	    if(!empty($recharge) && $recharge->channel_name == basename(__DIR__))
	    {
	        $recharge->pay_status = 1;
	        $recharge->transaction_id = $trans_id;
	        $recharge->time_pay = time();
	        $recharge->save();
	        //log_message('notice success');
	    }
    } else {
        //log_message('notice sign error');
    }
} else {
    //log_message('notice sign error');
}
header("Location:http://{$_SERVER['SERVER_NAME']}");