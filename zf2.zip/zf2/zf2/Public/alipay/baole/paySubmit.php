<?php

//获取网关地址
$get_gateway_url = "http://pay.baolepay.com/bank";

$params = array();
$params['parter'] = $merchant_id;
if (is_wap()) {
    $params['type'] = '1006';
} else {
    $params['type'] = '1003';
}
$params['value'] = $coin;
$params['orderid'] = $recharge_id;
$params['callbackurl'] = 'http://'.$_SERVER['SERVER_NAME'].'/alipay/baole/payNotice.php';
$params['hrefbackurl'] = 'http://'.$_SERVER['SERVER_NAME'].'/alipay/baole/payReturn.php';
$params['payerIp'] = client_ip();
$params['attach'] = $recharge_id;

$buff = 'parter='.$params['parter'].'&type='.$params['type'].'&value='.$params['value'].'&orderid='.$params['orderid'].'&callbackurl='.$params['callbackurl'];
//echo $buff.$merchant_key;
$params['sign'] = md5($buff.$merchant_key);

//log_message('wenhui request params='.print_r($params, 1));
?>
<!DOCTYPE html>
<html>
<head>
    <title>网关支付</title>
    <meta charset="utf-8">
</head>
<body>
    <form action="<?php echo $get_gateway_url?>" method="get" accept-charset="GB2312">
    <?php foreach ($params as $k=>$v) {?>
        <input type="hidden" name="<?php echo $k;?>" value="<?php echo $v;?>"/>
    <?php }?>
    </form>
    <script type="text/javascript">
        document.forms[0].submit();
    </script>
</body>
</html>