<?php
require_once realpath(__DIR__).'/../../../MyBootstrap.php';

$postData = $_REQUEST;
//log_message('bifu notice postinput='.var_export($postData,true));

$params = array(
	'partner_id'=>$postData['partner_id'],
    //'service_name'=>$postData['service_name'],
    //'input_charset'=>$postData['input_charset'],
    //'version'=>$postData['version'],
    //'sign_type'=>'',
    //'sign'=>'',
    'resp_code'=>$postData['resp_code'],
    'resp_desc'=>$postData['resp_desc'],
    'notify_type'=>$postData['notify_type'],
    'out_trade_no'=>$postData['out_trade_no'],
    'order_sn'=>$postData['order_sn'],
    'order_amount'=>$postData['order_amount'],
    'order_time'=>$postData['order_time'],
    'trade_time'=>$postData['trade_time'],
    //'extend_param'=>$postData['extend_param'],
    'trade_status'=>$postData['trade_status'],
);
if(isset($postData['extend_param']) && $postData['extend_param']) {
    $params['extend_param'] = $postData['extend_param'];
}

$channel = \Db\Mall\Channel::row(array('merchant_id'=>$params['partner_id']));
if(empty($channel) || $channel->channel_name != basename(__DIR__)){exit(0);}

$arr = $params;
ksort($arr);
$buff = "";
foreach ($arr as $x => $x_value){
	if($x_value != '' && !is_array($x_value)){
		$buff .= "{$x}={$x_value}&";
	}
}
$sign = strtoupper(md5($buff.'key='.$channel->merchant_key));

$flag = $sign == $postData['sign'];
//log_message('check sign: '.(int)$flag);

$order_no = $params['out_trade_no'];

if($flag)
{
    if('RESPONSE_SUCCESS' == $params['resp_code']) {
        $trans_id = $order_no;
        $trans_part = explode('_', $trans_id);
        $account = $trans_part[0];
        $recharge_id = $trans_part[1];
        $recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id, 'pay_status'=>0));
        if(!empty($recharge) && $recharge->channel_name == basename(__DIR__))
        {
            $recharge->pay_status = 1;
            $recharge->transaction_id = $trans_id;
            $recharge->time_pay = time();
            $recharge->save();
            //log_message('notice success');
        }
    }
    $result="SUCCESS";
} else {
    $result="fail";
}
echo $result;