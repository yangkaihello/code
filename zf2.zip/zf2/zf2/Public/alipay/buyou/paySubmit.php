<?php
$gateway_url =  "https://submit.buucard.com/PayBank.aspx";
// $version = '3.0';
// $method = 'Rx.online.pay';
$partner = $merchant_id;
if(is_wap())
{
    $banktype = 'ALIPAYWAP';
}
else 
{
    $banktype = 'ALIPAY';
}

// $banktype = 'ALIPAY';

$paramsmoney = $coin;

$ordernumber = $order_no;


// 这里填写支付完成后，支付平台后台通知当前支付是否成功的URL
$callbackurl = 'http://'.$_SERVER['SERVER_NAME'].'/alipay/buyou/payNotice.php';
// 这里填写支付完成后，支付平台后台通知当前支付是否成功的URL
$hrefbackurl = 'http://'.$_SERVER['SERVER_NAME'].'/alipay/buyou/payReturn.php';

$isshow = 1;


$pre_sign_format = "partner=%s&banktype=%s&paymoney=%s&ordernumber=%s&callbackurl=%s{$merchant_key}";

$sign = md5(sprintf($pre_sign_format, $partner, $banktype, $paramsmoney, $ordernumber, $callbackurl));

?>

<!DOCTYPE html>
<html>
<head>
    <title>网关支付</title>
    <meta charset="utf-8">
</head>
<body>
    <form action="<?php echo $gateway_url?>" method="get">
        <input type="hidden" name="partner" value="<?php echo $partner?>"/>
        <input type="hidden" name="banktype" value="<?php echo $banktype?>"/>
        <input type="hidden" name="paymoney" value="<?php echo $paramsmoney?>"/>
        <input type="hidden" name="ordernumber" value="<?php echo $ordernumber?>"/>
        <input type="hidden" name="callbackurl" value="<?php echo $callbackurl?>"/>
        <input type="hidden" name="hrefbackurl" value="<?php echo $hrefbackurl?>"/>
        <input type="hidden" name="isshow" value="<?php echo $isshow?>"/>
        <input type="hidden" name="sign" value="<?php echo $sign?>"/>
    </form>
    <script type="text/javascript">
        document.forms[0].submit();
    </script>
</body>
</html>