<?php 
require("help.php");
$apiurl = "http://www.dypay1.com/GateWay/ReceiveBank.aspx";


$merchantKey = $merchant_key;

$p0_Cmd = 'Buy';
$p1_MerId = $merchant_id;
$p2_Order = $order_no;
$p3_Amt = $coin;
$p4_Cur = 'CNY';
$p5_Pid = $product_name;
$p6_Pcat = $product_name;
$p7_Pdesc = $product_name;

$p8_Url = 'http://'.$_SERVER['SERVER_NAME'].'/alipay/dongyi/payNotice.php';
$p9_SAF = "0";
if(is_wap())
{
    $pd_FrpId = 'alipaywap';
}
else 
{
    $pd_FrpId = 'alipayd';
}
$pd_FrpId = 'alipay';
$pa_MP = $return_params;
$pr_NeedResponse = 1;
$hmac = getReqHmacString($merchantKey, $p0_Cmd, $p1_MerId, $p2_Order, $p3_Amt, $p4_Cur, $p5_Pid, $p6_Pcat, $p7_Pdesc, $p8_Url, $p9_SAF, $pa_MP, $pd_FrpId, $pr_NeedResponse);

?>

<!DOCTYPE html>
<html>
<head>
    <title>网关支付</title>
    <meta charset="utf-8">
</head>
<body>
    <form action="<?php echo $apiurl?>" method="post">
        <input type='hidden' name='p0_Cmd'					value='<?php echo $p0_Cmd; ?>'>
        <input type='hidden' name='p1_MerId'				value='<?php echo $p1_MerId; ?>'>
        <input type='hidden' name='p2_Order'				value='<?php echo $p2_Order; ?>'>
        <input type='hidden' name='p3_Amt'					value='<?php echo $p3_Amt; ?>'>
        <input type='hidden' name='p4_Cur'					value='<?php echo $p4_Cur; ?>'>
        <input type='hidden' name='p5_Pid'					value='<?php echo $p5_Pid; ?>'>
        <input type='hidden' name='p6_Pcat'					value='<?php echo $p6_Pcat; ?>'>
        <input type='hidden' name='p7_Pdesc'				value='<?php echo $p7_Pdesc; ?>'>
        <input type='hidden' name='p8_Url'					value='<?php echo $p8_Url; ?>'>
        <input type='hidden' name='p9_SAF'					value='<?php echo $p9_SAF; ?>'>
        <input type='hidden' name='pa_MP'					value='<?php echo $pa_MP; ?>'>
        <input type='hidden' name='pd_FrpId'				value='<?php echo $pd_FrpId; ?>'>
        <input type='hidden' name='pr_NeedResponse'	        value='<?php echo $pr_NeedResponse; ?>'>
        <input type='hidden' name='hmac'					value='<?php echo $hmac; ?>'>
    </form>
    <script type="text/javascript">
        document.forms[0].submit();
    </script>
</body>
</html>