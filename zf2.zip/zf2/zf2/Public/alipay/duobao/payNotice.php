<?php
require_once realpath(__DIR__).'/../../../MyBootstrap.php';

//log_message('duobao notice:'.var_export($_REQUEST, true));

$params = array(
    'code' => $_REQUEST['code'],
    'message' => $_REQUEST['message'],
    'order_no' => $_REQUEST['order_no'],
    'trade_no' => $_REQUEST['trade_no'],
    'amount' => $_REQUEST['amount'],
    'partner_id' => $_REQUEST['partner_id'],
    'attach' => isset($_REQUEST['attach'])?$_REQUEST['attach']:'',
    'sign' => $_REQUEST['sign'],
);


$channel = \Db\Mall\Channel::row(array('merchant_id'=>$params['partner_id']));
if(empty($channel) || $channel->channel_name != basename(__DIR__)){exit(0);}


$arr = $params;
unset($arr['sign']);
ksort($arr);
$buff = "";
foreach ($arr as $x => $x_value){
	if($x_value!=='' && !is_array($x_value)){
		$buff .= "{$x}={$x_value}&";
	}
}
$buff = trim($buff, "&");

$sign = strtolower(md5("{$buff}&{$channel->merchant_key}"));

$flag = $sign==$params['sign'];
//log_message("check sign = ".(int)$flag);

$OrderId = $params['attach'];
if($flag)
{
    if('00' == $params['code'])
    {
        $trans_id = $OrderId;
	    $trans_part = explode('_', $trans_id);
	    $account = $trans_part[0];
	    $recharge_id = $trans_part[1];
	    $recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id, 'pay_status'=>0));
	    if(!empty($recharge) && $recharge->channel_name == basename(__DIR__))
	    {
	        $recharge->pay_status = 1;
	        $recharge->transaction_id = $trans_id;
	        $recharge->time_pay = time();
	        $recharge->save();
	        //log_message('notice success');
	    }
    }
}
echo 'ok';