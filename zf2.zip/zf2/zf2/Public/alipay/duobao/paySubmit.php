<?php
/*
 */
require_once 'help.php';
$http = is_https()?'https://':'http://';

//获取网关地址
$get_gateway_url = "https://api.bankspay.net/payment/gateway";
//$params = $merchant_id;
if(is_wap()) {
    $params_type = '0005';
} else {
    $params_type = '0003';
}
$params = array();
$params['version'] = 'V1.0';
$params['partner_id'] = $merchant_id;
$params['pay_type'] = $params_type;
$params['bank_code'] = '';
$params['order_no'] = $recharge_id;
$params['amount'] = str_replace(',', '', number_format($coin, 2));
$params['notify_url'] = $http.$_SERVER['SERVER_NAME'].'/alipay/duobao/payNotice.php';
$params['return_url'] = $http.$_SERVER['SERVER_NAME'].'/alipay/duobao/payReturn.php';
//$params['summary'] = 'Y';
$params['attach'] = $order_no;

$arr = $params;
ksort($arr);
$buff = "";
foreach ($arr as $x => $x_value){
	if($x_value!=='' && !is_array($x_value)){
		$buff .= "{$x}={$x_value}&";
	}
}
$buff = trim($buff, "&");

$params['sign'] = strtolower(md5($buff.'&'.$merchant_key));

?>
<!DOCTYPE html>
<html>
<head>
    <title>网关支付</title>
    <meta charset="utf-8">
</head>
<body>
    <form action="<?php echo $get_gateway_url?>" method="post">
    <?php foreach ($params as $k=>$v) {?>
        <input type="hidden" name="<?php echo $k;?>" value="<?php echo $v;?>"/>
    <?php }?>
    </form>
    <script type="text/javascript">
        document.forms[0].submit();
    </script>
</body>
</html>