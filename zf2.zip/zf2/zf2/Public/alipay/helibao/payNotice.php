<?php
require_once realpath(__DIR__).'/../../../MyBootstrap.php';

//log_message('notice:'.var_export($_REQUEST, true));
//商户�?
$r1_merchantNo = $_REQUEST['r1_merchantNo'];
$r2_orderNumber = $_REQUEST['r2_orderNumber'];//
$r3_serialNumber = $_REQUEST['r3_serialNumber'];
$r4_orderStatus = $_REQUEST['r4_orderStatus'];
$r5_amount = $_REQUEST['r5_amount'];
$r6_currency = $_REQUEST['r6_currency'];
$r7_timestamp = $_REQUEST['r7_timestamp'];
$sign = $_REQUEST['sign'];

$channel = \Db\Mall\Channel::row(array('merchant_id'=>$r1_merchantNo));
if(empty($channel) || $channel->channel_name != basename(__DIR__)){exit(0);}

$sign_pre = sprintf('#%s#%s#%s#%s#%s#%s#%s#%s',$r1_merchantNo, $r2_orderNumber, $r3_serialNumber, $r4_orderStatus, $r5_amount, $r6_currency, $r7_timestamp, $channel->merchant_key); 
$sign_check = md5($sign_pre);

if ($sign_check == $sign)
{
    if ($r4_orderStatus == "SUCCESS")
    {
        $trans_id = $r2_orderNumber;
	    $trans_part = explode('_', $trans_id);
	    $account = $trans_part[0];
	    $recharge_id = $trans_part[1];
	    $recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id, 'pay_status'=>0));
	    if(!empty($recharge) && $recharge->channel_name == basename(__DIR__))
	    {
	        $recharge->pay_status = 1;
	        $recharge->transaction_id = $trans_id;
	        $recharge->time_pay = time();
	        $recharge->save();
	    } 
    }
    echo 'success';
}