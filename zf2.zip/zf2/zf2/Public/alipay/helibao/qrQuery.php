<?php
require_once realpath(__DIR__).'/../../../MyBootstrap.php';
require("myRequest.php");

$host = 'http://api.99juhe.com/trx-service/appPay/api.action';

$data['trxType'] = 'AppPayQuery';

$data['r1_merchantNo'] = $_GET['merchant_id'];
$data['r2_orderNumber'] = $_GET['order_no'];

$channel = \Db\Mall\Channel::row(array('merchant_id'=> $data['r1_merchantNo']));
if(empty($channel) || $channel->channel_name != basename(__DIR__)){exit(0);}

$sign_pre = sprintf("#%s#%s#%s#%s",$data['trxType'], $data['r1_merchantNo'], $data['r2_orderNumber'], $channel->merchant_key);

$sign= md5($sign_pre);


$data['sign'] = $sign;

$params = http_build_query($data);

$rs = myRequest::post($host, $params);

$response = json_decode($rs->response, true);

if ('0000' == $response['retCode'])
{       
	if($response['r4_orderStatus'] == 'SUCCESS')
	{
        $trans_id = $response['r2_orderNumber'];
        $trans_part = explode('_', $trans_id);
        $account = $trans_part[0];
        $recharge_id = $trans_part[1];
        $recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id));
        if(!empty($recharge) && $recharge->channel_name == basename(__DIR__))
        {
            $recharge->pay_status = 1;
            $recharge->transaction_id = $trans_id;
            $recharge->time_pay = time();
            $recharge->save();
        } 
	}
}
    
echo $rs->response;
exit();