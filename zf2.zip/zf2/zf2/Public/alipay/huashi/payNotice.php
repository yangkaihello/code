<?php
require("helper.php");
require_once realpath(__DIR__).'/../../../MyBootstrap.php';

//log_message('notice:'.var_export($_REQUEST, true));

$notify_type	    = $_REQUEST['notify_type'];	

$notify_id		= $_REQUEST['notify_id'];	

$notify_time	= $_REQUEST['notify_time'];
$sign	    = $_REQUEST['sign'];	

$sign_type	= $_REQUEST['sign_type'];	

$trade_no           = $_REQUEST['trade_no'];

$order_no           = $_REQUEST['order_no'];
$paramsment_type           = $_REQUEST['payment_type'];
$title           = $_REQUEST['title'];
$body           = $_REQUEST['body'];
$total_fee           = $_REQUEST['total_fee'];

$trade_status          = $_REQUEST['trade_status'];

$seller_email          = $_REQUEST['seller_email'];
$seller_id          = $_REQUEST['seller_id'];
$buyer_email          = $_REQUEST['buyer_email'];
$buyer_id          = $_REQUEST['buyer_id'];
$gmt_create          = $_REQUEST['gmt_create'];
$gmt_payment          = $_REQUEST['gmt_payment'];

$channel = \Db\Mall\Channel::row(array('merchant_id'=>$body));
if(empty($channel) || $channel->channel_name != basename(__DIR__)){exit(0);}
$merchant_key = $channel->merchant_key;

$sign_md5 = buildMysign($_REQUEST, $merchant_key);

if($sign_md5 == $sign)
{
    if($trade_status == 'TRADE_FINISHED')
    {
        $trans_id = $order_no;
        $trans_part = explode('_', $trans_id);
        $account = $trans_part[0];
        $recharge_id = $trans_part[1];
        $recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id, 'pay_status'=>0));
        if(!empty($recharge) && $recharge->channel_name == basename(__DIR__))
        {
            $recharge->pay_status = 1;
            $recharge->transaction_id = $trans_id;
            $recharge->time_pay = time();
            $recharge->save();
        }
    }
}

echo 'success';