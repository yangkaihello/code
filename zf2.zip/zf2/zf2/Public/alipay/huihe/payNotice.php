<?php
require_once realpath(__DIR__).'/../../../MyBootstrap.php';


//$postData = trim(file_get_contents('php://input'));
$postData = $_REQUEST;
//log_message('huihe notice postinput='.var_export($postData,true));

$recharge = \Db\Account\Recharge::row(array('recharge_id'=>$postData['OutTradeNo']));
if(empty($recharge)){exit(0);}
$channel = \Db\Mall\Channel::row(array('merchant_id'=>$recharge->merchant_id));
if(empty($channel) || $channel->channel_name != basename(__DIR__)){exit(0);}

//log_message('check sign='.$postData['Sign']);

$OrderId = $recharge->user_account.'_'.$postData['OutTradeNo'];

if('0' == $postData['Code'] && !!$postData['TradeNo'])
{
    $trans_id = $OrderId;
    $trans_part = explode('_', $trans_id);
    $account = $trans_part[0];
    $recharge_id = $trans_part[1];
    $recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id, 'pay_status'=>0));
    if(!empty($recharge) && $recharge->channel_name == basename(__DIR__))
    {
        $recharge->pay_status = 1;
        $recharge->transaction_id = $trans_id;
        $recharge->time_pay = time();
        $recharge->save();
        //log_message('notice success');
    }
    echo 'SUCCESS';
}
else {
    echo 'FAIL';  
}
exit(0);