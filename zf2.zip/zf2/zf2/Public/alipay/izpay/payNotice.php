<?php
require_once realpath(__DIR__).'/../../../MyBootstrap.php';


//$postData = trim(file_get_contents('php://input'));
$postData = $_REQUEST;
//log_message('izpay notice postinput='.var_export($postData,true));

$recharge = \Db\Account\Recharge::row(array('recharge_id'=>$postData['out_trade_no']));
if(empty($recharge)){exit(0);}
$channel = \Db\Mall\Channel::row(array('merchant_id'=>$recharge->merchant_id));
if(empty($channel) || $channel->channel_name != basename(__DIR__)){exit(0);}

$arr = $postData;
unset($arr['sign']);
ksort($arr);
$buff = "mer_id=".$recharge->merchant_id.'&out_trade_no='.$postData['out_trade_no'].'&pay_type='.$postData['pay_type'].'&total_fee='.$postData['total_fee'];
$sign = md5($buff.'&key='.$channel->merchant_key);

$flag = $sign==$postData['sign'];
//log_message('check sign='.(int)$flag);

$OrderId = $recharge->user_account.'_'.$postData['out_trade_no'];
if($flag)
{
    if('0' == $postData['result'])
    {
        $trans_id = $OrderId;
	    $trans_part = explode('_', $trans_id);
	    $account = $trans_part[0];
	    $recharge_id = $trans_part[1];
	    $recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id, 'pay_status'=>0));
	    if(!empty($recharge) && $recharge->channel_name == basename(__DIR__))
	    {
	        $recharge->pay_status = 1;
	        $recharge->transaction_id = $trans_id;
	        $recharge->time_pay = time();
	        $recharge->save();
	        //log_message('notice success');
	    }
    }
}
echo 'success';
exit(0);