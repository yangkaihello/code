<?php
require_once realpath(__DIR__).'/../../../MyBootstrap.php';
//$show=false;

$merchant_code = $_GET['merchant_id'];
$merchant_no = $_GET['order_no'];
$ordercode = $merchant_no;

$trans_id = $ordercode;
$trans_part = explode('_', $trans_id);
$account = $trans_part[0];
$recharge_id = $trans_part[1];
$recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id));
if(!empty($recharge) && $recharge->pay_status==1) {
    echo 'success';
} else {
   echo 'fail'; 
}
exit(0);

