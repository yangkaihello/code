<?php
class help
{
    public static function formatBizQueryParaMap($paraMap, $urlencode)
    {
        $buff = "";
        ksort ( $paraMap );
        foreach ( $paraMap as $k => $v )
        {
	        if($k == "signature" || empty($v) || $v == 'null')
			{
			    continue;
			}
            else
            {
                if ($urlencode)
                {
                    $v = urlencode ( $v );
                }
                $buff .= $k . "=" . $v . "&";
            }
        }
        $reqPar = '';
        if (strlen ( $buff ) > 0)
        {
            $reqPar = substr ( $buff, 0, strlen ( $buff ) - 1 );
        }
        return $reqPar;
    }
    
    /**
     * 作用：生成签名
     */
    public static function getSign($arr, $key)
    {
        $String = self::formatBizQueryParaMap ( $arr, false );
        $String = $String . "&" . $key;
        //var_dump($String);exit();
        $String = mb_convert_encoding($String, 'gbk', 'utf-8');
        //$String = @iconv('UTF-8', 'GBK' . '//TRANSLIT//IGNORE', $String);
        //var_dump($String);exit();
        $rs = strtoupper(md5($String));
        return $rs;
    }
}