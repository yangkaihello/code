<?php
require("help.php");
require_once realpath(__DIR__).'/../../../MyBootstrap.php';

//log_message('return:'.file_get_contents("php://input"));

foreach ($_REQUEST as $key => $val)
{
	$val = urldecode($val);
	$_REQUEST[$key] = mb_convert_encoding($val, 'utf-8', 'gbk');
}

$channel = \Db\Mall\Channel::row(array('merchant_id'=>$_REQUEST['merchno']));
if(empty($channel) || $channel->channel_name != basename(__DIR__)){exit(0);}

$sign = help::getSign($_REQUEST, $channel->merchant_key);

if ($sign == $_REQUEST['signature'])
{
    if (1 == $_REQUEST['status'])
    {        
		
        $trans_id = $_REQUEST['traceno'];
	    $trans_part = explode('_', $trans_id);
	    $account = $trans_part[0];
	    $recharge_id = $trans_part[1];
	    $recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id, 'pay_status'=>0));
	    if(!empty($recharge) && $recharge->channel_name == basename(__DIR__))
	    {
	        $recharge->pay_status = 1;
	        $recharge->transaction_id = $trans_id;
	        $recharge->time_pay = time();
	        $recharge->save();
	    } 
    }
    exit('success');
}
exit('fail');