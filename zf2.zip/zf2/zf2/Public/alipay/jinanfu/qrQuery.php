<?php
require_once realpath(__DIR__).'/../../../MyBootstrap.php';
require("help.php");
require("myRequest.php");
$host = 'http://112.74.230.8:8081/posp-api/qrcodeQuery';


$data['traceno'] = $_GET['order_no'];
$data['merchno'] = $_GET['merchant_id'];

$channel = \Db\Mall\Channel::row(array('merchant_id'=> $data['merchno']));
if(empty($channel) || $channel->channel_name != basename(__DIR__)){exit(0);}

$sign = help::getSign($data, $channel->merchant_key);

$data['signature'] = $sign;

$params = http_build_query($data);
$params = iconv('utf-8', 'gbk', $params);

$rs = myRequest::post($host, $params);
$response = iconv('gbk', 'utf-8', $rs->response);
$rs = json_decode($response, true);
if (1 == $rs['respCode'])
{        
	
    $trans_id = $rs['traceno'];
    $trans_part = explode('_', $trans_id);
    $account = $trans_part[0];
    $recharge_id = $trans_part[1];
    $recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id));
    if(!empty($recharge) && $recharge->channel_name == basename(__DIR__))
    {
        $recharge->pay_status = 1;
        $recharge->transaction_id = $trans_id;
        $recharge->time_pay = time();
        $recharge->save();
    } 
}
    
echo $response;
exit();
