<?php
require_once realpath(__DIR__).'/../../../MyBootstrap.php';

//log_message('jinfuka return:'.var_export($_REQUEST, true));

function yinban_decrypt($data, $private_key) 
{
    $priKey= openssl_get_privatekey($private_key);
    $data=base64_decode($data);
    $Split = str_split($data, 128);
    $back='';
    foreach($Split as $k=>$v)
    {
        openssl_private_decrypt($v, $decrypted, $priKey);
        $back.= $decrypted;
    }

    return $back;
}
	

$sign=$_REQUEST['sign'];//数字签名
$merId=$_REQUEST['merId'];//商户�?
$version=$_REQUEST['version'];//版本�?
$encParam=$_REQUEST['encParam'];//业务参数


$channel = \Db\Mall\Channel::row(array('merchant_id'=>$merId));
if(empty($channel) || $channel->channel_name != basename(__DIR__)){exit(0);}
$public_key = $channel->public_key;
$private_key = $channel->private_key;
$public_key = "-----BEGIN PUBLIC KEY-----\n" . chunk_split($public_key, 64, "\n") . "-----END PUBLIC KEY-----";
$private_key = "-----BEGIN RSA PRIVATE KEY-----\n" . chunk_split($private_key, 64, "\n") . "-----END RSA PRIVATE KEY-----";
//验证签名与业务参数是否通过
if(openssl_verify(base64_decode($encParam),base64_decode($sign),$public_key))
{
    $res=json_decode(yinban_decrypt($encParam, $private_key),true);
	//表示支付成功
    if($res['order_state']=='1003')
    {
    	$trans_id = $res['orderId'];
	    $trans_part = explode('_', $trans_id);
	    $account = $trans_part[0];
	    $recharge_id = $trans_part[1];
	    $recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id, 'pay_status'=>0));
	    if(!empty($recharge) && $recharge->channel_name == basename(__DIR__))
	    {
	        $recharge->pay_status = 1;
	        $recharge->transaction_id = $trans_id;
	        $recharge->time_pay = time();
	        $recharge->save();
	    } 
        echo "SUCCESS";//通知服务器我收到�?
    }
}
header("Location:http://{$_SERVER['SERVER_NAME']}");