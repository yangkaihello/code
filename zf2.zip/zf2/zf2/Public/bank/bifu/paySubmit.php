<?php 

$gate_way_url = 'https://pay.beeepay.com/payment/gateway';

$params = array(
    'partner_id'=>$merchant_id,
    'service_name'=>'PTY_ONLINE_PAY',
    'input_charset'=>'UTF-8',
    'version'=>'V3.5.0',
    //'sign_type'=>'',
    //'sign'=>'',
    'out_trade_no'=>$order_no,
    'order_amount'=>str_replace(',', '', number_format($coin, 2)),
    'order_time'=>date('Y-m-d H:i:s',time()),
    'return_url'=>"http://{$_SERVER['SERVER_NAME']}",
    'notify_url'=>"http://{$_SERVER['SERVER_NAME']}/bank/bifu/payNotice.php",
    'pay_type'=>'BANK_PAY',
    //'bank_code'=>'ALIPAY_QRCODE',
    //'summary'=>$product_name,
    //'extend_param'=>'',
);

$arr = $params;
ksort($arr);
$buff = "";
foreach ($arr as $x => $x_value){
	if($x_value != '' && !is_array($x_value)){
		$buff .= "{$x}={$x_value}&";
	}
}
$sign = strtoupper(md5($buff.'key='.$merchant_key));

$params['sign_type'] = 'MD5';
$params['sign'] = $sign;
?>
<!DOCTYPE html>
<html>
<head>
    <title>网关支付</title>
    <meta charset="utf-8">
</head>
<body>
    <form action="<?php echo $gate_way_url?>" method="POST">
    	<?php foreach($params as $k=>$v):?>
        <input type="hidden" name="<?php echo $k;?>" value="<?php echo $v;?>" />
        <?php endforeach;?>
    </form>
    <script type="text/javascript">
        document.forms[0].submit();
    </script>
</body>
</html>
