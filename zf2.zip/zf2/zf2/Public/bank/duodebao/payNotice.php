<?php
require_once realpath(__DIR__).'/../../../MyBootstrap.php';

//log_message('duodebao notice:'.var_export($_REQUEST, true));

$params = array(
    'merchant_code'=>$_REQUEST['merchant_code'],
    'notify_type'=>$_REQUEST['notify_type'],
    'notify_id'=>$_REQUEST['notify_id'],
    'interface_version'=>$_REQUEST['interface_version'],
    'sign_type'=>$_REQUEST['sign_type'],
    'sign'=>$_REQUEST['sign'],
    'order_no'=>$_REQUEST['order_no'],
    'order_time'=>$_REQUEST['order_time'],
    'order_amount'=>$_REQUEST['order_amount'],
    'extra_return_param'=>isset($_REQUEST['extra_return_param'])?$_REQUEST['extra_return_param']:'',
    'trade_no'=>$_REQUEST['trade_no'],
    'trade_time'=>$_REQUEST['trade_time'],
    'trade_status'=>$_REQUEST['trade_status'],
    'bank_seq_no'=>isset($_REQUEST['bank_seq_no'])?$_REQUEST['bank_seq_no']:'',
);

/* 排序并组装签名字符串 */
$arr = $params;
ksort($arr);
$buff = "";
foreach ($arr as $x => $x_value){
	if($x !='sign_type' && $x !='sign' && $x_value != '' && !is_array($x_value)){
		$buff .= "{$x}={$x_value}&";
	}
}
$buff = trim($buff, "&");

$dinpaySign = base64_decode($params["sign"]);

$channel = \Db\Mall\Channel::row(array('merchant_id'=>$params['merchant_code']));
if(empty($channel) || $channel->channel_name != basename(__DIR__)){exit(0);}
$public_key = $channel->public_key;
$public_key = "-----BEGIN PUBLIC KEY-----\n" . chunk_split($public_key, 64, "\n") . "-----END PUBLIC KEY-----";

$dinpay_public_key = openssl_get_publickey($public_key);

$flag = openssl_verify($buff,$dinpaySign,$dinpay_public_key,OPENSSL_ALGO_MD5);

//log_message('check sign: '.(int)$flag);

$result='';
$order_no = str_replace('AADUODEBAOAA', '_', $params['order_no']);

if($flag==true)
{
    if ($params['trade_status'] == "SUCCESS")
    {
        $trans_id = $order_no;
        $trans_part = explode('_', $trans_id);
        $account = $trans_part[0];
        $recharge_id = $trans_part[1];
        $recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id, 'pay_status'=>0));
        if(!empty($recharge) && $recharge->channel_name == basename(__DIR__))
        {
            $recharge->pay_status = 1;
            $recharge->transaction_id = $trans_id;
            $recharge->time_pay = time();
            $recharge->save();
        } 
    }
    
    $result="SUCCESS";
    
}else{
    $result="FAIL";
}
if($params['notify_type'] == 'offline_notify') {
    echo $result;
} else {
    redirect('/');
}