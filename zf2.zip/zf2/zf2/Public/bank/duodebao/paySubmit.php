<?php 

$gate_way_url = 'https://pay.ddbill.com/gateway?input_charset=UTF-8';

$params = array(
    'merchant_code'=>$merchant_id,
    'service_type'=>'direct_pay',
    'notify_url'=>$http.$_SERVER['SERVER_NAME'].'/bank/duodebao/payNotice.php',
	'interface_version'=>'V3.0',
	'input_charset'=>'UTF-8',
	'sign_type'=>'RSA-S',
	//'sign'=>'',
	'return_url'=>'http://'.$_SERVER['SERVER_NAME'].'/bank/duodebao/payNotice.php',
    'pay_type'=>'',
	'client_ip'=>'',
	//'client_ip_check'=>0,

	'order_no'=>str_replace('_','AADUODEBAOAA',$order_no), //不允许特殊字符 
	'order_time'=>date('Y-m-d H:i:s' ,time()),
	'order_amount'=>str_replace(',', '', number_format($coin, 2)),
	'bank_code'=>'',
	'redo_flag'=>'',
	'product_name'=>$product_name,
	'product_code'=>'',
	'product_num'=>'',
	'product_desc'=>'',
	'extra_return_param'=>'',
	'extend_param'=>'',
	'show_url'=>'',
	'orders_info'=>'',
);
/* 排序并组装签名字符串 */
$arr = $params;
ksort($arr);
$buff = "";
foreach ($arr as $x => $x_value){
	if($x !='sign_type' && $x_value != '' && !is_array($x_value)){
		$buff .= "{$x}={$x_value}&";
	}
}
$buff = trim($buff, "&");
//var_dump($private_key);die;
$private_key = "-----BEGIN RSA PRIVATE KEY-----\n" . chunk_split($private_key, 64, "\n") . "-----END RSA PRIVATE KEY-----";
//var_dump($private_key);die;
$merchant_private_key = openssl_get_privatekey($private_key);

openssl_sign($buff,$sign_info,$merchant_private_key,OPENSSL_ALGO_MD5);

//var_dump($merchant_private_key,$sign_info);die;
$sign = base64_encode($sign_info);

$params['sign'] = $sign;

?>
<!DOCTYPE html>
<html>
<head>
    <title>网关支付</title>
    <meta charset="utf-8">
</head>
<body>
    <form action="<?php echo $gate_way_url?>" method="post">
    <?php foreach ($params as $k=>$v) {?>
        <input type="hidden" name="<?php echo $k;?>" value="<?php echo $v;?>"/>
    <?php }?>
    </form>
    <script type="text/javascript">
        document.forms[0].submit();
    </script>
</body>
</html>