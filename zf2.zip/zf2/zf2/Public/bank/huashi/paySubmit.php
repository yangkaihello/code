<?php 
require("helper.php");
$apiurl = "http://ebank.payworth.net/portal";

$parameter = array(
    "service"       => 'online_pay',
    "merchant_ID"    => $merchant_id,
    "notify_url"     =>  'http://'.$_SERVER['SERVER_NAME'].'/wx/huashi/payNotice.php',
    "return_url"     =>  'http://'.$_SERVER['SERVER_NAME'].'/wx/huashi/payReturn.php',
   
    "charset"  => 'UTF-8',
    "title"  => $product_name,
    "body"  => $merchant_id,
    "order_no"  => $order_no,
    "total_fee"  => $coin,
    "payment_type"  => 1,
    "paymethod"  => 'directPay',
    
    "defaultbank"     => '',
    "isApp"     => '',
    "seller_email"     => $platform_id,

);
$parameter['sign'] = buildMysign($parameter, $merchant_key);
$parameter['sign_type'] = 'MD5';
?>
<!DOCTYPE html>
<html>
<head>
    <title>网关支付</title>
    <meta charset="utf-8">
</head>
<body>
    <form action="<?php echo $apiurl?>" method="get">
    	<?php foreach ($parameter as $key => $val):?>
        <input type="hidden" name="<?php echo $key?>" value="<?php echo $val?>"/>
        <?php endforeach;?>
    </form>
    <script type="text/javascript">
        document.forms[0].submit();
    </script>
</body>
</html>