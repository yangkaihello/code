<?php
$public_key = "-----BEGIN PUBLIC KEY-----\n" . chunk_split($public_key, 64, "\n") . "-----END PUBLIC KEY-----";
$private_key = "-----BEGIN RSA PRIVATE KEY-----\n" . chunk_split($private_key, 64, "\n") . "-----END RSA PRIVATE KEY-----";
$priKey= openssl_get_privatekey($private_key);
$pubkey= openssl_pkey_get_public($public_key);
$orderId = $order_no;
$Gold = $coin*100;//分为单位
$form_url='https://www.goldenpay88.com/gateway/orderPay';

$sign = '';
$merId = $merchant_id;
$version ="1.0.9";
$terId = $platform_id;
$businessOrdid = $orderId;
$orderName = $product_name;
$tradeMoney = array();
//$selfParam = $LogID;
$selfParam = $orderId;

//支付方式编号
//默认支所有支付方�?
//1000 默认支持所�?
//1001 快捷支付
//1002 刷卡器支�?
//1003 银行卡支�?
//1005 微信扫码支付
//1006 支付宝扫码支�?
//1007 外卡支付
//1008 支付宝APP 支付
//1009 微信APP 支付

$paramsType = '1003';
//应用场景默认PC 1001
//1001 PC
//网关支付接口说明�?
//1002 H5
//1003 快捷API 对接
//1004 快捷SDK
if(is_wap())
{
	$appSence = '1002';
}
else
{
	$appSence = '1001';
}
$appSence = '1001';


$syncUrl = 'http://'.$_SERVER['SERVER_NAME'].'/wx/jinfuka/payReturn.php';
$asyncUrl = 'http://'.$_SERVER['SERVER_NAME'].'/wx/jinfuka/payNotice.php';
$_encParam = array(
    'terId'=>$terId,
    'businessOrdid'=>$businessOrdid,
    'orderName'=>$orderName,
    'merId'=>$merId,
    'tradeMoney'=>$Gold,
    'payType'=>$paramsType,
    'syncURL'=>$syncUrl,
    'asynURL'=>$asyncUrl,
    'appSence'=>$appSence,
    'selfParam'=>$selfParam
);
//$this->orderLog($_encParam['businessOrdid']);//生成日志
$enc_json = json_encode($_encParam,JSON_UNESCAPED_UNICODE);
$Split = str_split($enc_json, 64);
$encParam_encrypted = '';
foreach($Split as $Part)
{
    openssl_public_encrypt($Part,$PartialData,$pubkey);//服务器公钥加�?
    $t = strlen($PartialData);
    $encParam_encrypted .= $PartialData;
}

$encParam = base64_encode(($encParam_encrypted));//加密的业务参�?
openssl_sign($encParam_encrypted, $sign_info, $priKey);
$sign = base64_encode($sign_info);//加密业务参数的签�?

$str='<html>';
$str.='<head>';
$str.='<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">';
$str.='</head>';
$str.='正在跳转 ...';
$str.='<body onLoad="document.dinpayForm.submit();">';
$str.='<form name="dinpayForm" method="post" action="'.$form_url.'" target="_self">';
$str.='<input type="hidden" name="sign"		  value="'.$sign.'" />';
$str.='<input type="hidden" name="merId"     value="'.$merId.'"/>';
$str.='<input type="hidden" name="version"     value="'.$version.'"/>';
$str.='<input type="hidden" name="encParam"     value="'.$encParam.'"/>';
$str.='</form>';
$str.='</body>';
$str.='</html>';
echo $str;
