<?php
require_once realpath(__DIR__).'/../../../MyBootstrap.php';

//log_message('jinhaizhe notice:'.var_export($_REQUEST, true));

$params = array(
    'ret' => @json_decode($_REQUEST['ret'],true),
    'msg' => @json_decode($_REQUEST['msg'],true),
    'sign' => $_REQUEST['sign']
);
$channel = \Db\Mall\Channel::row(array('merchant_id'=>$params['msg']['remarks']));
if(empty($channel) || $channel->channel_name != basename(__DIR__)){exit(0);}
$sign = "{$_REQUEST['ret']}|{$_REQUEST['msg']}";
$public_key = "-----BEGIN PUBLIC KEY-----\n" . chunk_split($channel->public_key, 64, "\n") . "-----END PUBLIC KEY-----";;

$flag = openssl_verify($sign,base64_decode($params['sign']),$public_key);
//log_message('sign:'.(int)$flag);

$OrderId = $params['msg']['no'];
if($flag)
{
    if($params['ret']['code']=='1000')
    {
        $trans_id = $OrderId;
	    $trans_part = explode('_', $trans_id);
	    $account = $trans_part[0];
	    $recharge_id = $trans_part[1];
	    $recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id, 'pay_status'=>0));
	    if(!empty($recharge) && $recharge->channel_name == basename(__DIR__))
	    {
	        $recharge->pay_status = 1;
	        $recharge->transaction_id = $trans_id;
	        $recharge->time_pay = time();
	        $recharge->save();
	        //log_message('notice success');
	    }
	    echo 'SUCCESS';
	    exit(0);
    }
}
echo 'fail';