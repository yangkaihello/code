<?php

$time = time();
//获取网关地址
$get_gateway_url = "http://zf.szjhzxxkj.com/ownPay/pay";

$params = array();
$params['merchantNo'] = $merchant_id;
$params['requestNo'] = $order_no;
$params['amount'] = 100*$coin;
/**
 * 微信业务�?012
支付宝业务号[400010]  5002
网页1005
 */
if(is_wap())
{
    $params['payMethod'] = '6002';
}
else
{
    $params['payMethod'] = '6002';
}
$params['pageUrl'] = 'http://'.$_SERVER['SERVER_NAME'];
$params['backUrl'] = 'http://'.$_SERVER['SERVER_NAME'].'/bank/jinhaizhe/payNotice.php';
$params['payDate'] = $time;
$params['agencyCode'] = 0;
$params['cashier'] = 0;
$params['remark1'] = $merchant_id;
$params['remark2'] = $product_name;
$params['remark3'] = $product_name;

$params['signature'] = "{$params['merchantNo']}|{$params['requestNo']}|{$params['amount']}|{$params['pageUrl']}|{$params['backUrl']}|{$params['payDate']}|{$params['agencyCode']}|{$params['remark1']}|{$params['remark2']}|{$params['remark3']}";

$private_key = "-----BEGIN RSA PRIVATE KEY-----\n" . chunk_split($private_key, 64, "\n") . "-----END RSA PRIVATE KEY-----";;
//$public_key = "-----BEGIN PUBLIC KEY-----\n" . chunk_split($public_key, 64, "\n") . "-----END PUBLIC KEY-----";;
		

$pr_key = openssl_pkey_get_private($private_key);
//$pu_key = openssl_pkey_get_public($public_key);

$sign = '';
//openssl_sign(加密前的字符�?加密后的字符�?密钥:私钥);
openssl_sign($params['signature'],$sign,$pr_key);
openssl_free_key($pr_key);
$params['signature'] = base64_encode($sign);

/**
 * {"backQrCodeUrl":"weixin://wxpay/bizpayurl?pr=fV3Ix3e",
 * {"msg":"请求流水重复","code":"2021"}
 */
$response = Even\Curl::post($get_gateway_url,http_build_query($params),array(
    CURLOPT_HEADER => 0,
 )
 );
//var_dump($response);die;
//log_message('request qr='.$response->response);
$response = json_decode($response->response,true);

$err_message = '';
$code_img = '';
if(!isset($response['backQrCodeUrl']) || !$response['backQrCodeUrl']) {
    $err_message = $response['msg'];
} else {
    $code_img = $response['backQrCodeUrl'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>网关支付</title>
    <meta charset="utf-8">
</head>
<body>
    <form action="<?php echo $get_gateway_url?>" method="get">
        <input type="hidden" name="merchantNo" value="<?php echo $params['merchantNo']?>"/>
        <input type="hidden" name="requestNo" value="<?php echo $params['requestNo']?>"/>
        <input type="hidden" name="payMethod" value="<?php echo $params['payMethod']?>"/>
        <input type="hidden" name="amount" value="<?php echo $params['amount']?>"/>
        <input type="hidden" name="pageUrl" value="<?php echo $params['pageUrl']?>"/>
        <input type="hidden" name="backUrl" value="<?php echo $params['backUrl']?>"/>
        <input type="hidden" name="payDate" value="<?php echo $params['payDate']?>"/>
		<input type="hidden" name="agencyCode" value="<?php echo $params['agencyCode']?>"/>
		<input type="hidden" name="cashier" value="<?php echo $params['cashier']?>"/>
		<input type="hidden" name="remark1" value="<?php echo $params['remark1']?>"/>
		<input type="hidden" name="remark2" value="<?php echo $params['remark2']?>"/>
		<input type="hidden" name="remark3" value="<?php echo $params['remark3']?>"/>
        <input type="hidden" name="signature" value="<?php echo $params['signature']?>"/>
    </form>
    <script type="text/javascript">
        document.forms[0].submit();
    </script>
</body>
</html>
