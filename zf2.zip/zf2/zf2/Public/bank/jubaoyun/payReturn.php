<?php
require_once realpath(__DIR__).'/../../../MyBootstrap.php';

include 'jubaopay.php';

//log_message('return:'.var_export($_REQUEST, true));

$message=$_REQUEST["message"];
$signature=$_REQUEST["signature"];
$remark=$_REQUEST["remark"];

$channel = \Db\Mall\Channel::row(array('merchant_id'=>$remark));  
if(empty($channel) || $channel->channel_name != basename(__DIR__)){exit(0);}
// 商户�?
$merchant_id = $channel->merchant_id;
// 密钥
$public_key = $channel->public_key;
// 密钥
$private_key = $channel->private_key;
// 密钥
$merchant_key = $channel->merchant_key;    
$jubaopay=new jubaopay($merchant_key, $public_key, $private_key);

$jubaopay->decrypt($message);
// 校验签名，然后进行业务处�?
$result=$jubaopay->verify($signature);

if($result == 1) 
{
    
    $paramsid = $jubaopay->getEncrypt("payid");
    $mobile = $jubaopay->getEncrypt("mobile");
    $amount = $jubaopay->getEncrypt("amount");
    $remark = $jubaopay->getEncrypt("remark");
    $orderNo = $jubaopay->getEncrypt("orderNo");
    $state = $jubaopay->getEncrypt("state");
    $modifyTime = $jubaopay->getEncrypt("modifyTime");
    $partnerid = $jubaopay->getEncrypt("partnerid");
    $realReceive = $jubaopay->getEncrypt("realReceive");
    if($state == 2)
    {
        $trans_id = $jubaopay->getEncrypt("payid");
        $trans_part = explode('_', $trans_id);
        $account = $trans_part[0];
        $recharge_id = $trans_part[1];
        $recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id, 'pay_status'=>0));
        if(!empty($recharge) && $recharge->channel_name == basename(__DIR__))
        {
            $recharge->pay_status = 1;
            $recharge->transaction_id = $trans_id;
            $recharge->time_pay = time();
            $recharge->save();
        }
    }    
}
header("Location:http://{$_SERVER['SERVER_NAME']}");