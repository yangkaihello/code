<?php

include 'jubaopay.php';


header("Content-Type: text/html; charset=UTF-8");

$paramsid= $order_no;
$partnerid= $merchant_id;
$amount=$coin;
$paramserName=$account;
$remark=$merchant_id;
$returnURL= 'http://'.$_SERVER['SERVER_NAME'].'/bank/jubaoyun/payReturn.php';    // 可在商户后台设置
$callBackURL='http://'.$_SERVER['SERVER_NAME'].'/bank/jubaoyun/payNotice.php';  // 可在商户后台设置
$paramsMethod='WANGYIN';
$goodsName=$product_name;

//////////////////////////////////////////////////////////////////////////////////////////////////
 //商户利用支付订单（payid）和商户号（mobile）进行对账查�?$jubaopay=new jubaopay($merchant_key, $public_key, $private_key);
$jubaopay->setEncrypt("payid", $paramsid);
$jubaopay->setEncrypt("partnerid", $partnerid);
$jubaopay->setEncrypt("amount", $amount);
$jubaopay->setEncrypt("payerName", $paramserName);
$jubaopay->setEncrypt("remark", $remark);
$jubaopay->setEncrypt("returnURL", $returnURL);
$jubaopay->setEncrypt("callBackURL", $callBackURL);
$jubaopay->setEncrypt("goodsName", $goodsName);

//对交易进行加�?$message并签�?$signature
$jubaopay->interpret();
$message=$jubaopay->message;
$signature=$jubaopay->signature;
//将message和signature一起aPOST到聚宝支�??>
<form method="post" action="https://mapi.jubaopay.com/apiwapsyt.htm" id="payForm">
	<input type="hidden" name="message" value="<?php echo $message;?>">
	<input type="hidden" name="signature" value="<?php echo $signature;?>">
</form>

<script type="text/javascript">
    document.getElementById('payForm').submit();
</script>