<?php
require_once realpath(__DIR__).'/../../../MyBootstrap.php';
//log_message('juyuan return:'.var_export($_REQUEST, true));
$partner = $_REQUEST['partner'];
$channel = \Db\Mall\Channel::row(array('merchant_id'=>$partner));
if(empty($channel) || $channel->channel_name != basename(__DIR__)){exit(0);}
$Key = $channel->merchant_key;
$orderstatus = $_REQUEST["orderstatus"];
$ordernumber = $_REQUEST["ordernumber"];
$paramsmoney = $_REQUEST["paymoney"];
$sign = $_REQUEST["sign"];
$attach = $_REQUEST["attach"];
$signSource = sprintf("partner=%s&ordernumber=%s&orderstatus=%s&paymoney=%s%s", $partner, $ordernumber, $orderstatus, $paramsmoney, $Key);
if ($sign == md5($signSource))//签名正确
{
    if($orderstatus == 1)
    {
        $trans_id = $ordernumber;
        $trans_part = explode('_', $trans_id);
        $account = $trans_part[0];
        $recharge_id = $trans_part[1];
        $recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id, 'pay_status'=>0));
        if(!empty($recharge) && $recharge->channel_name == basename(__DIR__))
        {
            $recharge->pay_status = 1;
            $recharge->transaction_id = $trans_id;
            $recharge->time_pay = time();
            $recharge->save();
        }
    }
}
header("Location:http://{$_SERVER['SERVER_NAME']}");