<?php 

$apiurl = "http://api.kcpay.net/paybank.aspx";
$partner = $merchant_id;
$key = $merchant_key;
$ordernumber = $order_no;
$banktype = 'default';
$attach = $order_no;
$paramsmoney = $coin;
$callbackurl = 'http://'.$_SERVER['SERVER_NAME'].'/bank/kacheng/payNotice.php';
$hrefbackurl = 'http://'.$_SERVER['SERVER_NAME'].'/bank/kacheng/payReturn.php';

$signSource = sprintf("partner=%s&banktype=%s&paymoney=%s&ordernumber=%s&callbackurl=%s%s", $partner, $banktype, $paramsmoney, $ordernumber, $callbackurl, $key);
$sign = md5($signSource);
?>

<!DOCTYPE html>
<html>
<head>
    <title>网关支付</title>
    <meta charset="utf-8">
</head>
<body>
    <form action="<?php echo $apiurl?>" method="get">
        <input type="hidden" name="banktype" value="<?php echo $banktype?>"/>
        <input type="hidden" name="partner" value="<?php echo $partner?>"/>
        <input type="hidden" name="paymoney" value="<?php echo $paramsmoney?>"/>
        <input type="hidden" name="ordernumber" value="<?php echo $ordernumber?>"/>
        <input type="hidden" name="callbackurl" value="<?php echo $callbackurl?>"/>
        <input type="hidden" name="hrefbackurl" value="<?php echo $hrefbackurl?>"/>
        <input type="hidden" name="attach" value="<?php echo $attach?>"/>
        <input type="hidden" name="sign" value="<?php echo $sign?>"/>
    </form>
    <script type="text/javascript">
        document.forms[0].submit();
    </script>
</body>
</html>