<?php
require_once realpath(__DIR__).'/../../../MyBootstrap.php';
//log_message('return:'.var_export($_REQUEST, true));

$OrderId=$_REQUEST["P_OrderId"];
$CardId=$_REQUEST["P_CardId"];
$CardPass=$_REQUEST["P_CardPass"];
$FaceValue=$_REQUEST["P_FaceValue"];
$ChannelId=$_REQUEST["P_ChannelId"];
$subject=$_REQUEST["P_Subject"];
$description=$_REQUEST["P_Description"];
$price=$_REQUEST["P_Price"];
$quantity=$_REQUEST["P_Quantity"];
$notic=$_REQUEST["P_Notic"];
$ErrCode=$_REQUEST["P_ErrCode"];
$PostKey=$_REQUEST["P_PostKey"];
$paramsMoney=$_REQUEST["P_PayMoney"];
$ErrMsg=$_REQUEST["P_ErrMsg"];

$UserId = $notic;
$channel = \Db\Mall\Channel::row(array('merchant_id'=>$UserId));
if(empty($channel) || $channel->channel_name != basename(__DIR__)){exit(0);}

$SalfStr = $channel->merchant_key;

$preEncodeStr=$UserId."|".$OrderId."|".$CardId."|".$CardPass."|".$FaceValue."|".$ChannelId."|".$paramsMoney."|".$ErrCode."|".$SalfStr;

$encodeStr=md5($preEncodeStr);

if($PostKey==$encodeStr)
{
    if($ErrCode=="0")
    {
        $trans_id = $OrderId;
	    $trans_part = explode('_', $trans_id);
	    $account = $trans_part[0];
	    $recharge_id = $trans_part[1];
	    $recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id, 'pay_status'=>0));
	    if(!empty($recharge) && $recharge->channel_name == basename(__DIR__))
	    {
	        $recharge->pay_status = 1;
	        $recharge->transaction_id = $trans_id;
	        $recharge->time_pay = time();
	        $recharge->save();
	    } 
    }
}

header("Location:http://{$_SERVER['SERVER_NAME']}");