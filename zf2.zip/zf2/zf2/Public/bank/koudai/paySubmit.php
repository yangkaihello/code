<?php
require_once 'help.php';
$http = is_https()?'https://':'http://';

//获取网关地址
$get_gateway_url = "https://GetUrl.DuQee.Com/Pay/KDSubmitUrl.aspx";
$P_UserId = $merchant_id;
$P_ServiceName = 'GetBankGateway';
$P_TimesTamp = time();
$P_Description = '';
$P_Notic = $P_UserId;
$SalfStr = $merchant_key;
$P_PostKey = md5("{$P_UserId}|{$P_ServiceName}|{$P_TimesTamp}|{$SalfStr}");
$response = Even\Curl::get(
"{$get_gateway_url}?P_UserId={$P_UserId}&P_ServiceName={$P_ServiceName}&P_TimesTamp={$P_TimesTamp}&P_PostKey={$P_PostKey}"
,array(CURLOPT_HEADER=>0)
);
$response = @json_decode($response->response,true);

if(!isset($response['P_SubmitUrl']) || !$response['P_SubmitUrl']) {
    redirect($http.$_SERVER['SERVER_NAME']);
}

$submitUrl = $response['P_SubmitUrl'];

//header("Content-type: text/html; charset=utf-8");

//$gateway_url =  "https://api.duqee.com/pay/KDBank.aspx";
//$gateway_url = "https://api.duqee.com/pay/KDQRSrc.aspx";
// 商户号
$P_UserId = $merchant_id;
// 订单号
$P_OrderId = $order_no;
$P_CardId = '';
$P_CardPass = '';
// 订单金额
$P_FaceValue = str_replace(',', '', number_format($coin, 2));
//1银行 | 2支付宝 | 21微信  || 调起微信33
$P_ChannelId = '1';
// 商品名称
$P_Subject = $product_name;
// 商品价格
$P_Price = $P_FaceValue;
// 商品数量
$P_Quantity = $product_num;
// 用户附加信息
$P_Notic = $P_UserId;

// 银行通道
$P_Description = '10003';
$P_Result_URL = $http.$_SERVER['SERVER_NAME'].'/bank/koudai/payNotice.php';//异步通知地址
$P_Notify_URL = $http.$_SERVER['SERVER_NAME'].'/bank/koudai/payReturn.php';//跳转地址

$SalfStr = $merchant_key;

//$preEncodeStr=$P_UserId."|".$P_OrderId."|".$P_CardId."|".$P_CardPass."|".$P_FaceValue."|".$P_ChannelId."|".$SalfStr;
$preEncodeStr=$P_UserId."|".$P_OrderId."|".$P_CardId."|".$P_CardPass."|".$P_FaceValue."|".$P_ChannelId."|".$SalfStr;

$P_PostKey=md5($preEncodeStr);
if(is_wap())
{
    $P_IsSmart = '1';
}
else
{
    $P_IsSmart = '0';
}
//P_UserId=1000190&P_OrderId=201702211421139213208&P_CardId=&P_CardPass=&P_FaceValue=0.01
//&P_ChannelId=21&P_Subject=&P_Price=0.01&P_IsSMart=&P_Quantity=&P_Description=21&P_Notic=
//&P_Result_url=http://xx/test/result_url.asp1&P_Notify_url=http://xx/test/notify_Url.asp&P_PostKey=da023cdb004b3c95c4023211dca87a6d
$params = array(
 'P_UserId'=>$P_UserId,
 'P_OrderId'=>$P_OrderId,
 'P_CardId'=>$P_CardId,
 'P_CardPass'=>$P_CardPass,
 'P_FaceValue'=>$P_FaceValue,
 'P_ChannelId'=>$P_ChannelId,
 'P_Subject'=>$P_Subject,
 'P_Price'=>$P_Price,
 'P_Quantity'=>$P_Quantity,
 'P_Description'=>$P_Description,
 'P_Notic'=>$P_Notic,
 'P_Result_URL'=>$P_Result_URL,
 'P_Notify_URL'=>$P_Notify_URL,
 'P_PostKey'=>$P_PostKey,
 'P_IsSmart'=>$P_IsSmart,
);
//$submitUrl = $submitUrl.'?'.http_build_query($params);
?>
<!DOCTYPE html>
<html>
<head>
    <title>网关支付</title>
    <meta charset="utf-8">
</head>
<body>
    <form action="<?php echo $submitUrl?>" method="get">
    <?php foreach ($params as $k=>$v) {?>
        <input type="hidden" name="<?php echo $k;?>" value="<?php echo $v;?>"/>
    <?php }?>
    </form>
    <script type="text/javascript">
        document.forms[0].submit();
    </script>
</body>
</html>

<?php
exit(0);
header("Content-type: text/html; charset=utf-8");

$gateway_url =  "https://api.duqee.com/pay/KDBank.aspx";
// 商户号
$P_UserId = $merchant_id;
// 订单号
$P_OrderId = $order_no;
$P_CardId = '';
$P_CardPass = '';
// 订单金额
$P_FaceValue = str_replace(',', '', number_format($coin, 2));
//1银行 | 2支付宝 | 21微信  | 吊起微信33
$P_ChannelId = '1';
// 商品名称
$P_Subject = $product_name;
// 商品价格
$P_Price = $P_FaceValue;

// 商品数量
$P_Quantity = $product_num;
// 用户附加信息
$P_Notic = $P_UserId;

// 银行通道
$P_Description = '10003';
$P_Notify_URL = 'http://'.$_SERVER['SERVER_NAME'].'/bank/koudai/payNotice.php';
$P_Result_URL = 'http://'.$_SERVER['SERVER_NAME'].'/bank/koudai/payReturn.php';

$SalfStr = $merchant_key;

$preEncodeStr=$P_UserId."|".$P_OrderId."|".$P_CardId."|".$P_CardPass."|".$P_FaceValue."|".$P_ChannelId."|".$SalfStr;

$P_PostKey=md5($preEncodeStr);
if(is_wap())
{
    $P_IsSmart = '1';
}
else
{
    $P_IsSmart = '0';
}


?>

<!DOCTYPE html>
<html>
<head>
    <title>网关支付</title>
    <meta charset="utf-8">
</head>
<body>
    <form action="<?php echo $gateway_url?>" method="post">
        <input type="hidden" name="P_UserId" value="<?php echo $P_UserId?>"/>
        <input type="hidden" name="P_OrderId" value="<?php echo $P_OrderId?>"/>
        <input type="hidden" name="P_CardId" value="<?php echo $P_CardId?>"/>
        <input type="hidden" name="P_CardPass" value="<?php echo $P_CardPass?>"/>
        <input type="hidden" name="P_FaceValue" value="<?php echo $P_FaceValue?>"/>
        <input type="hidden" name="P_ChannelId" value="<?php echo $P_ChannelId?>"/>
        <input type="hidden" name="P_Subject" value="<?php echo $P_Subject?>"/>
        <input type="hidden" name="P_Price" value="<?php echo $P_Price?>"/>
        <input type="hidden" name="P_Quantity" value="<?php echo $P_Quantity?>"/>
        <input type="hidden" name="P_Description" value="<?php echo $P_Description?>"/>
        <input type="hidden" name="P_Notic" value="<?php echo $P_Notic?>"/>
        <input type="hidden" name="P_Result_URL" value="<?php echo $P_Result_URL?>"/>
        <input type="hidden" name="P_Notify_URL" value="<?php echo $P_Notify_URL?>"/>
        <input type="hidden" name="P_PostKey" value="<?php echo $P_PostKey?>"/>
        <input type="hidden" name="P_IsSmart" value="<?php echo $P_IsSmart?>"/>
    </form>
    <script type="text/javascript">
       document.forms[0].submit();
    </script>
</body>
</html>