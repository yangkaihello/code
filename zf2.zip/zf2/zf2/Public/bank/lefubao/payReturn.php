﻿<?php
require_once("MobaoPay.class.php");
require_once realpath(__DIR__).'/../../../MyBootstrap.php';

//log_message('return:'.var_export($_REQUEST, true));

// Mo宝支付系统网关地址（正式环境）
$mobaopay_gateway = "http://trade.gannun.cn/cgi-bin/netpayment/pay_gate.cgi";
//$mobaopay_gateway = "http://bis.exambo.cn/cgi-bin/netpayment/pay_gate.cgi";

// 请求数据赋值
$data = "";
$data['apiName'] = $_REQUEST["apiName"];
// 通知时间
$data['notifyTime'] = $_REQUEST["notifyTime"];
// 支付金额(单位元，显示用)
$data['tradeAmt'] = $_REQUEST["tradeAmt"];
// 商户号
$data['merchNo'] = $_REQUEST["merchNo"];
// 商户参数，支付平台返回商户上传的参数，可以为空
$data['merchParam'] = $_REQUEST["merchParam"];
// 商户订单号
$data['orderNo'] = $_REQUEST["orderNo"];
// 商户订单日期
$data['tradeDate'] = $_REQUEST["tradeDate"];
// Mo宝支付订单号
$data['accNo'] = $_REQUEST["accNo"];
// Mo宝支付账务日期
$data['accDate'] = $_REQUEST["accDate"];
// 订单状态，0-未支付，1-支付成功，2-失败，4-部分退款，5-退款，9-退款处理中
$data['orderStatus'] = $_REQUEST["orderStatus"];
// 签名数据
$data['signMsg'] = $_REQUEST["signMsg"];


$channel = \Db\Mall\Channel::row(array('merchant_id'=>$data['merchNo']));
if(empty($channel) || $channel->channel_name != basename(__DIR__)){exit(0);}

$mbp_key = $channel->merchant_key;

// 初始化
$cMbPay = new MbPay($mbp_key, $mobaopay_gateway);
// 准备准备验签数据
$str_to_sign = $cMbPay->prepareSign($data);
// 验证签名
$resultVerify = $cMbPay->verify($str_to_sign, $data['signMsg']);


if ($resultVerify) 
{
	if ($data['orderStatus'] == '1')
	{
    	$trans_id = $data['orderNo'];
    	$trans_part = explode('_', $trans_id);
    	$account = $trans_part[0];
    	$recharge_id = $trans_part[1];
    	$recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id, 'pay_status'=>0));
    	if(!empty($recharge) && $recharge->channel_name == basename(__DIR__))
    	{
    	    $recharge->pay_status = 1;
    	    $recharge->transaction_id = $trans_id;
    	    $recharge->time_pay = time();
    	    $recharge->save();
    	}
	}
}

header("Location:http://{$_SERVER['SERVER_NAME']}");