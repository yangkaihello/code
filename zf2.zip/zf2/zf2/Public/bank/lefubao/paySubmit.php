﻿<?php
/* *
 * 功能：一般支付处理文件
 * 版本：1.0
 * 日期：2012-03-26
 * 说明：
 * 以下代码只是为了方便商户测试而提供的样例代码。
 */
 
//require_once("Mobaopay.Config.php");
require_once("MobaoPay.class.php");

$mobaopay_apiname_pay = "WEB_PAY_B2C";
//	$mobaopay_apiname_pay = "WECHAT_PAY";
// 商户APINAME，商户订单信息查询
$mobaopay_apiname_query = "MOBO_TRAN_QUERY";
// 商户APINAME，Mo宝支付退款申请
$mobaopay_apiname_refund = "MOBO_TRAN_RETURN";
// 商户API版本
$mobaopay_api_version = "1.0.0.0";

/****以下信息以实际为准****/

// Mo宝支付系统网关地址（正式环境）
$mobaopay_gateway = "https://trade.gannun.cn/cgi-bin/netpayment/pay_gate.cgi";
//$mobaopay_gateway = "http://bis.exambo.cn/cgi-bin/netpayment/pay_gate.cgi";

// Mo宝支付系统密钥
// 	$mbp_key = "b87ade8eb2321835daa0330d581c7123";
// 	$mbp_key = "19d0f5f1583d691f71a0d640ef5e8e08";
$mbp_key = $merchant_key;
// 商户在Mo宝支付的平台号
// 	$platform_id = "210001510010949";
// 	$platform_id = "210001520010058";
$platform_id = $platform_id;
// Mo宝支付分配给商户的账号
// 	$merchant_acc = "210001510010949";
// 	$merchant_acc = "210001520010058";
$merchant_acc = $merchant_id;
// 商户通知地址（请根据自己的部署情况设置下面的路径）
$merchant_notify_url = 'http://'.$_SERVER['SERVER_NAME'].'/bank/lefubao/payReturn.php';

// 请求数据赋值
$data = "";
// 商户APINMAE，WEB渠道一般支付
$data['apiName'] = $mobaopay_apiname_pay;
// 商户API版本
$data['apiVersion'] = $mobaopay_api_version;
// 商户在Mo宝支付的平台号
$data['platformID'] = $platform_id;
// Mo宝支付分配给商户的账号
$data['merchNo'] = $merchant_acc;
// 商户通知地址
$data['merchUrl'] = $merchant_notify_url;
// 银行代码，不传输此参数则跳转Mo宝收银台
// 1网银支付 5微信扫码
$data['choosePayType'] = '1';

//商户订单号
$data['orderNo'] = $order_no;
// 商户订单日期
$data['tradeDate'] = date('Ymd');
// 商户交易金额
$data['amt'] = $coin;
// 商户参数
$data['merchParam'] = $return_params;
// 商户交易摘要
$data['tradeSummary'] = $return_params;

$data['customerIP'] = '127.0.0.1';

// 对含有中文的参数进行UTF-8编码
// 将中文转换为UTF-8
if(!preg_match("/[\xe0-\xef][\x80-\xbf]{2}/", $data['merchUrl']))
{
$data['merchUrl'] = iconv("GBK","UTF-8", $data['merchUrl']);
}

if(!preg_match("/[\xe0-\xef][\x80-\xbf]{2}/", $data['merchParam']))
{

$data['merchParam'] = iconv("GBK","UTF-8", $data['merchParam']);
}

if(!preg_match("/[\xe0-\xef][\x80-\xbf]{2}/", $data['tradeSummary']))
{
$data['tradeSummary'] = iconv("GBK","UTF-8", $data['tradeSummary']);
}

// 初始化
$cMbPay = new MbPay($mbp_key, $mobaopay_gateway);
// 准备待签名数据
$str_to_sign = $cMbPay->prepareSign($data);
// 数据签名
$sign = $cMbPay->sign($str_to_sign);
$data['signMsg'] = $sign;
// 生成表单数据
//var_export($data);exit();
//echo $mobaopay_gateway.'?'.http_build_query($data);exit();
echo $cMbPay->buildForm($data, $mobaopay_gateway);
//echo $cMbPay->getQrUrl($data);

//$cMbPay->mobaopayOrder($data);