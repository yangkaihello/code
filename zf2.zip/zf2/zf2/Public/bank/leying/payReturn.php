﻿<?php
require_once realpath(__DIR__).'/../../../MyBootstrap.php';
//log_message('return:'.var_export($_REQUEST, true));
$orderID = $_REQUEST["orderID"];
$resultCode = $_REQUEST["resultCode"];
$stateCode = $_REQUEST["stateCode"];
$orderAmount = $_REQUEST["orderAmount"];
$paramsAmount = $_REQUEST["payAmount"];
$acquiringTime = $_REQUEST["acquiringTime"];
$completeTime = $_REQUEST["completeTime"];
$orderNo = $_REQUEST["orderNo"];
$partnerID = $_REQUEST["partnerID"];
$remark = $_REQUEST["remark"];
$charset = $_REQUEST["charset"];
$signType = $_REQUEST["signType"];
$signMsg = $_REQUEST["signMsg"];
			
$src = "orderID=".$orderID
."&resultCode=".$resultCode
."&stateCode=".$stateCode
."&orderAmount=".$orderAmount
."&payAmount=".$paramsAmount
."&acquiringTime=".$acquiringTime
."&completeTime=".$completeTime
."&orderNo=".$orderNo
."&partnerID=".$partnerID
."&remark=".$remark
."&charset=".$charset
."&signType=".$signType;

if($_REQUEST["charset"] == 1)
{
    $charset = "UTF8";
}
$channel = \Db\Mall\Channel::row(array('merchant_id'=>$partnerID));
if(empty($channel) || $channel->channel_name != basename(__DIR__)){exit(0);}
$pkey = $channel->merchant_key;

if(2 == $signType) //md5验签
{
	$src = $src."&pkey=".$pkey;
	if($signMsg == md5($src))
	{
	    $trans_id = $remark;
        $trans_part = explode('_', $trans_id);
        $account = $trans_part[0];
        $recharge_id = $trans_part[1];
        $recharge = \Db\Account\Recharge::row(array('recharge_id'=>$recharge_id, 'pay_status'=>0));
        if(!empty($recharge) && $recharge->channel_name == basename(__DIR__))
        {
            $recharge->pay_status = 1;
            $recharge->transaction_id = $trans_id;
            $recharge->time_pay = time();
            $recharge->save();
        } 
	}
}

header("Location:http://{$_SERVER['SERVER_NAME']}");