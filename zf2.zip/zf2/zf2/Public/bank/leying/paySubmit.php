<?php
$url = 'https://www.funpay.com/website/pay.htm';   
$version = 2.6; 

$serialID = $order_no;

$submitTime = date('YmdHis', time());
$failureTime = date('YmdHis', strtotime("+1 year"));
$customerIP = client_ip();

$totalAmount = $coin * 100;
$orderDetails = "{$serialID},{$totalAmount},上海易生,recharge,1";

$type = '1000';

$buyerMarked = '';
$paramsType = 'BANK_B2C';
$orgCode = 'unionpay';
$currencyCode = 1;
$directFlag = 0;
$borrowingMarked = 0;
$couponFlag = 1;
$platformID = '';
$pkey = $merchant_key;
// var_dump($pkey);exit();
$noticeUrl = 'http://'.$_SERVER['SERVER_NAME'].'/bank/leying/payReturn.php';
$returnUrl = 'http://'.$_SERVER['SERVER_NAME'].'/bank/leying/payReturn.php';
$partnerID = $merchant_id;
$remark = $return_params;
$charset = '1';
$signType = 2;

$signMsg = "version=".$version
         ."&serialID=".$serialID
         ."&submitTime=".$submitTime
         ."&failureTime=".$failureTime
         ."&customerIP=".$customerIP
         ."&orderDetails=".$orderDetails
         ."&totalAmount=".$totalAmount
         ."&type=".$type
         ."&buyerMarked=".$buyerMarked
         ."&payType=".$paramsType
         ."&orgCode=".$orgCode
         ."&currencyCode=".$currencyCode
         ."&directFlag=".$directFlag
         ."&borrowingMarked=".$borrowingMarked
         ."&couponFlag=".$couponFlag
         ."&platformID=".$platformID
         ."&returnUrl=".$returnUrl
         ."&noticeUrl=".$noticeUrl
         ."&partnerID=".$partnerID
         ."&remark=".$remark
         ."&charset=".$charset
         ."&signType=".$signType;
             
$signMsg = $signMsg."&pkey=".$pkey;
$signMsg = md5($signMsg);             
             
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Pay Page</title>
</head>
<body>
<form action="<?php echo $url ?>" method="post" name="orderForm">
	<input type="hidden" name="version"  value="<?php echo $version?>"> 	
	<input type="hidden" name="serialID"  value="<?php echo $serialID ?>">
	<input type="hidden" name="submitTime"  value="<?php echo $submitTime ?>">
	<input type="hidden" name="failureTime"  value="<?php echo $failureTime ?>">
	<input type="hidden" name="customerIP"  value="<?php echo $customerIP ?>">
	<input type="hidden" name="orderDetails"  value="<?php echo $orderDetails ?>">
	<input type="hidden" name="totalAmount"  value="<?php echo $totalAmount ?>">
	<input type="hidden" name="type"  value="<?php echo $type ?>">
	<input type="hidden" name="buyerMarked"  value="<?php echo $buyerMarked ?>">
	<input type="hidden" name="payType"  value="<?php echo $paramsType ?>">
	<input type="hidden" name="orgCode"  value="<?php echo $orgCode ?>">
	<input type="hidden" name="currencyCode"  value="<?php echo $currencyCode?>">
	<input type="hidden" name="directFlag"  value="<?php echo $directFlag ?>">
	<input type="hidden" name="borrowingMarked"  value="<?php echo $borrowingMarked ?>">
	<input type="hidden" name="couponFlag"  value="<?php echo $couponFlag ?>">
	<input type="hidden" name="platformID"  value="<?php echo $platformID ?>">
	<input type="hidden" name="returnUrl"  value="<?php echo $returnUrl ?>">
	<input type="hidden" name="noticeUrl"  value="<?php echo $noticeUrl ?>">
	<input type="hidden" name="partnerID"  value="<?php echo $partnerID ?>">
	<input type="hidden" name="remark"  value="<?php echo $remark ?>">


	<input type="hidden" name="charset"  value="<?php echo $charset ?>">

	<input type="hidden" name="signType"  value="<?php echo $signType ?>">
	<input type="hidden" name="signMsg"   value="<?php echo $signMsg ?>">

</form>

<script type="text/javascript">

  document.orderForm.submit();

</script>
</body>
</html>